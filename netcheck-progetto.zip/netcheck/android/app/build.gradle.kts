plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }

// Numero di versione crescente: in GitHub Actions arriva da VERSION_CODE
val vCode = System.getenv("VERSION_CODE")?.toIntOrNull() ?: 1

android {
    namespace = "com.netcheck"
    compileSdk = 34
    defaultConfig {
        applicationId = "com.netcheck"; minSdk = 26; targetSdk = 34
        versionCode = vCode; versionName = "1.$vCode"
    }
    signingConfigs {
        create("release") {
            val path = System.getenv("KS_PATH")
            if (path != null) {
                storeFile = file(path)
                storePassword = System.getenv("KS_PASS")
                keyAlias = "netcheck"
                keyPassword = System.getenv("KS_PASS")
            }
        }
    }
    buildTypes {
        getByName("release") {
            isMinifyEnabled = false
            if (System.getenv("KS_PATH") != null) signingConfig = signingConfigs.getByName("release")
        }
    }
    lint { checkReleaseBuilds = false }
    compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
    kotlinOptions { jvmTarget = "17" }
}
dependencies {
    implementation("androidx.appcompat:appcompat:1.6.1")
    // ZXing: funziona anche senza Google Play Services (GrapheneOS, CalyxOS)
    implementation("com.journeyapps:zxing-android-embedded:4.3.0")
}
