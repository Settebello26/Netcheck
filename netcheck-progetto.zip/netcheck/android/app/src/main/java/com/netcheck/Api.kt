package com.netcheck

import java.io.IOException
import java.net.URL
import java.security.MessageDigest
import javax.net.ssl.HttpsURLConnection

/** Client HTTPS con pinning opzionale della chiave pubblica del server (SHA-256 SPKI, hex). */
object Api {
    class PinException : IOException("Certificato del server diverso dall'atteso")
    class Res(val code: Int, val body: String)

    private fun sha256(b: ByteArray) =
        MessageDigest.getInstance("SHA-256").digest(b).joinToString("") { "%02x".format(it) }

    fun call(base: String, path: String, pin: String?, body: String? = null): Res {
        require(base.startsWith("https://")) { "Server non HTTPS" }
        val c = URL(base.trimEnd('/') + path).openConnection() as HttpsURLConnection
        c.connectTimeout = 10_000; c.readTimeout = 20_000
        if (body != null) {
            c.requestMethod = "POST"; c.doOutput = true
            c.setRequestProperty("Content-Type", "application/json")
        }
        try {
            c.connect()
            if (!pin.isNullOrEmpty() && sha256(c.serverCertificates[0].publicKey.encoded) != pin.lowercase())
                throw PinException()
            body?.let { c.outputStream.use { o -> o.write(it.toByteArray()) } }
            val code = c.responseCode
            val s = if (code < 400) c.inputStream else c.errorStream
            return Res(code, s?.bufferedReader()?.readText() ?: "")
        } finally { c.disconnect() }
    }
}
