package com.netcheck

/** Stato condiviso tra servizio (che lavora in background) e schermata. */
object RunState {
    val log = StringBuilder()
    @Volatile var running = false
    @Volatile var progress = ""
    @Volatile var pct = 0
    @Volatile var alert: String? = null
    @Volatile var reportUrl: String? = null
    @Volatile var reportOpened = false
    @Volatile var onChange: (() -> Unit)? = null

    fun say(s: String) { synchronized(log) { log.append(s).append('\n') }; onChange?.invoke() }
    fun prog(s: String, p: Int = -1) { progress = s; if (p >= 0) pct = p; onChange?.invoke() }
    fun reset() {
        synchronized(log) { log.setLength(0) }
        progress = ""; pct = 0; alert = null; reportUrl = null; reportOpened = false
    }
}
