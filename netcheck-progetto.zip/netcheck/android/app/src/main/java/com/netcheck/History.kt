package com.netcheck

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/** Ultimi report visti su questo telefono (solo il link e l'esito). */
object History {
    private const val KEY = "history"

    class Item(val url: String, val ts: Long, val level: Int)

    fun add(ctx: Context, url: String, level: Int) {
        val sp = ctx.getSharedPreferences("netcheck", Context.MODE_PRIVATE)
        val old = try { JSONArray(sp.getString(KEY, "[]")) } catch (e: Exception) { JSONArray() }
        val out = JSONArray()
        out.put(JSONObject().put("url", url).put("ts", System.currentTimeMillis()).put("level", level))
        for (i in 0 until minOf(old.length(), 19)) out.put(old.getJSONObject(i))
        sp.edit().putString(KEY, out.toString()).apply()
    }

    fun list(ctx: Context): List<Item> {
        val sp = ctx.getSharedPreferences("netcheck", Context.MODE_PRIVATE)
        val arr = try { JSONArray(sp.getString(KEY, "[]")) } catch (e: Exception) { JSONArray() }
        val out = ArrayList<Item>()
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            out += Item(o.optString("url"), o.optLong("ts"), o.optInt("level"))
        }
        return out
    }
}
