package com.netcheck

import android.app.KeyguardManager
import android.app.admin.DevicePolicyManager
import android.content.Context
import android.content.pm.ApplicationInfo
import android.content.pm.PackageInfo
import android.content.pm.PackageManager
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.Build
import android.os.PowerManager
import android.provider.Settings
import org.json.JSONArray
import org.json.JSONObject
import java.net.InetAddress
import java.security.KeyStore
import java.security.cert.X509Certificate
import java.text.SimpleDateFormat
import java.util.Locale

/** level: 0 info, 1 attenzione, 2 critico */
data class Finding(val id: String, val title: String, val level: Int, val detail: String) {
    fun json(): JSONObject = JSONObject().put("id", id).put("title", title).put("level", level).put("detail", detail)
}

object Checks {
    private val SENSITIVE = setOf(
        "android.permission.RECORD_AUDIO", "android.permission.CAMERA",
        "android.permission.ACCESS_FINE_LOCATION", "android.permission.ACCESS_BACKGROUND_LOCATION",
        "android.permission.READ_SMS", "android.permission.RECEIVE_SMS",
        "android.permission.READ_CONTACTS", "android.permission.READ_CALL_LOG",
        "android.permission.READ_PHONE_STATE")
    private val KNOWN_DNS = setOf("1.1.1.1", "1.0.0.1", "8.8.8.8", "8.8.4.4", "9.9.9.9", "149.112.112.112",
        "208.67.222.222", "208.67.220.220", "94.140.14.14", "94.140.15.15")

    fun isPrivate(a: InetAddress): Boolean {
        val b = a.address
        return a.isSiteLocalAddress || a.isLoopbackAddress || a.isLinkLocalAddress ||
            (b.size == 16 && (b[0].toInt() and 0xfe) == 0xfc)
    }

    fun dnsServers(ctx: Context): Set<String> {
        val cm = ctx.getSystemService(ConnectivityManager::class.java)
        return cm.getLinkProperties(cm.activeNetwork)?.dnsServers?.mapNotNull { it.hostAddress }?.toSet() ?: emptySet()
    }

    fun run(ctx: Context, stalker: Set<String> = emptySet(), online: Boolean = false): List<Finding> {
        val out = mutableListOf<Finding>()
        val steps = listOf<Pair<String, (Context, MutableList<Finding>) -> Unit>>(
            "Certificati CA" to ::userCas, "Proxy" to ::proxy, "VPN" to ::vpn, "DNS" to ::dns,
            "Amministratori" to ::admins, "Accessibilita'" to ::accessibility,
            "Lettura notifiche" to ::listeners, "ADB" to ::adb, "App sospette" to { c: Context, o: MutableList<Finding> -> apps(c, o, stalker, online) },
            "Patch di sicurezza" to ::patch,
            "Blocco schermo" to ::lock, "Root" to ::root, "Tastiere" to ::keyboards)
        for ((name, fn) in steps) {
            try { fn(ctx, out) } catch (e: Exception) {
                out += Finding("err_$name", "Controllo non riuscito: $name", 0, e.javaClass.simpleName)
            }
        }
        return out
    }

    private fun label(ctx: Context, pkg: String) = try {
        val pm = ctx.packageManager; "${pm.getApplicationLabel(pm.getApplicationInfo(pkg, 0))} ($pkg)"
    } catch (e: Exception) { pkg }

    private fun isSystem(ctx: Context, pkg: String) = try {
        ctx.packageManager.getApplicationInfo(pkg, 0).flags and ApplicationInfo.FLAG_SYSTEM != 0
    } catch (e: Exception) { false }

    private fun userCas(ctx: Context, o: MutableList<Finding>) {
        val ks = KeyStore.getInstance("AndroidCAStore").apply { load(null) }
        val user = ks.aliases().toList().filter { it.startsWith("user:") }
        if (user.isEmpty()) o += Finding("ca", "Nessun certificato CA aggiunto dall'utente", 0, "Sistema pulito")
        else o += Finding("ca", "Certificati CA installati manualmente", 2,
            "Permettono di intercettare l'HTTPS: " + user.joinToString("; ") {
                (ks.getCertificate(it) as? X509Certificate)?.subjectX500Principal?.name ?: it })
    }

    private fun proxy(ctx: Context, o: MutableList<Finding>) {
        val cm = ctx.getSystemService(ConnectivityManager::class.java)
        val p = cm.defaultProxy ?: cm.getLinkProperties(cm.activeNetwork)?.httpProxy
        val sys = System.getProperty("http.proxyHost")
        if (p == null && sys.isNullOrEmpty()) o += Finding("proxy", "Nessun proxy configurato", 0, "")
        else o += Finding("proxy", "Proxy di rete attivo", 2, p?.toString() ?: sys.orEmpty())
    }

    private fun vpn(ctx: Context, o: MutableList<Finding>) {
        val cm = ctx.getSystemService(ConnectivityManager::class.java)
        val vpn = cm.getNetworkCapabilities(cm.activeNetwork)?.hasTransport(NetworkCapabilities.TRANSPORT_VPN) == true
        o += if (vpn) Finding("vpn", "VPN attiva", 1, "Tutto il traffico passa da un terzo (normale se e' la tua VPN)")
        else Finding("vpn", "Nessuna VPN attiva", 0, "")
    }

    private fun dns(ctx: Context, o: MutableList<Finding>) {
        val cm = ctx.getSystemService(ConnectivityManager::class.java)
        val lp = cm.getLinkProperties(cm.activeNetwork) ?: return
        val odd = lp.dnsServers.filter { !isPrivate(it) && it.hostAddress !in KNOWN_DNS }
        val priv = if (lp.isPrivateDnsActive) "DNS privato attivo (${lp.privateDnsServerName ?: "auto"})" else "DNS privato non attivo"
        val cell = cm.getNetworkCapabilities(cm.activeNetwork)?.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) == true
        val list = lp.dnsServers.joinToString { it.hostAddress ?: "?" }
        o += if (odd.isEmpty()) Finding("dns", "DNS: $list", 0, priv)
        else Finding("dns", "DNS sconosciuti", if (cell) 0 else 1,
            "${odd.joinToString { it.hostAddress ?: "?" }}. $priv" + if (cell) " (di solito assegnati dall'operatore mobile)" else "")
    }

    private fun admins(ctx: Context, o: MutableList<Finding>) {
        val dpm = ctx.getSystemService(DevicePolicyManager::class.java)
        val a = dpm.activeAdmins?.map { it.packageName } ?: emptyList()
        o += if (a.isEmpty()) Finding("admin", "Nessun amministratore del dispositivo", 0, "")
        else Finding("admin", "Amministratori del dispositivo attivi", if (a.all { isSystem(ctx, it) }) 0 else 1,
            a.joinToString { label(ctx, it) } + if (a.all { isSystem(ctx, it) }) " (componenti di sistema)" else "")
    }

    private fun components(raw: String?) = raw.orEmpty().split(":").filter { it.contains("/") }
        .map { it.substringBefore("/") }.distinct()

    private fun accessibility(ctx: Context, o: MutableList<Finding>) {
        val l = components(Settings.Secure.getString(ctx.contentResolver, "enabled_accessibility_services"))
        o += if (l.isEmpty()) Finding("a11y", "Nessun servizio di accessibilita'", 0, "")
        else Finding("a11y", "Servizi di accessibilita' attivi", if (l.any { !isSystem(ctx, it) }) 1 else 0,
            "Possono leggere lo schermo: " + l.joinToString { label(ctx, it) })
    }

    private fun listeners(ctx: Context, o: MutableList<Finding>) {
        val l = components(Settings.Secure.getString(ctx.contentResolver, "enabled_notification_listeners"))
        o += if (l.isEmpty()) Finding("notif", "Nessuna app legge le notifiche", 0, "")
        else Finding("notif", "App con lettura delle notifiche", if (l.any { !isSystem(ctx, it) }) 1 else 0,
            l.joinToString { label(ctx, it) })
    }

    private fun adb(ctx: Context, o: MutableList<Finding>) {
        val cr = ctx.contentResolver
        val usb = Settings.Global.getInt(cr, Settings.Global.ADB_ENABLED, 0) == 1
        val wifi = Settings.Global.getInt(cr, "adb_wifi_enabled", 0) == 1
        o += when {
            wifi -> Finding("adb", "Debug wireless (ADB) attivo", 2, "Accessibile dalla rete locale")
            usb -> Finding("adb", "Debug USB (ADB) attivo", 1, "Normale solo se sei uno sviluppatore")
            else -> Finding("adb", "ADB disattivato", 0, "")
        }
    }

    private val STORES = setOf("com.android.vending", "com.sec.android.app.samsungapps", "com.amazon.venezia",
        "org.fdroid.fdroid", "org.fdroid.basic", "com.huawei.appmarket", "com.xiaomi.mipicks", "com.heytap.market",
        "com.oppo.market", "com.vivo.appstore", "com.aurora.store")

    private val CODES = mapOf("android.permission.RECORD_AUDIO" to "mic", "android.permission.CAMERA" to "cam",
        "android.permission.ACCESS_FINE_LOCATION" to "loc", "android.permission.ACCESS_BACKGROUND_LOCATION" to "bgloc",
        "android.permission.READ_SMS" to "sms", "android.permission.RECEIVE_SMS" to "sms",
        "android.permission.READ_CONTACTS" to "contacts", "android.permission.READ_CALL_LOG" to "calls",
        "android.permission.READ_PHONE_STATE" to "phone")

    /** Elenco delle app installate (non di sistema) e conteggi, riempiti da apps(). */
    var lastInventory: JSONArray = JSONArray()
    var lastCounts: Pair<Int, Int> = 0 to 0

    private fun granted(p: PackageInfo, perm: String): Boolean {
        val r = p.requestedPermissions ?: return false
        val f = p.requestedPermissionsFlags ?: return false
        val i = r.indexOf(perm)
        return i >= 0 && (f[i] and PackageInfo.REQUESTED_PERMISSION_GRANTED) != 0
    }

    private fun names(l: List<String>) = l.take(12).joinToString("; ") + if (l.size > 12) " ... e altre ${l.size - 12}" else ""

    private fun appName(ctx: Context, pkg: String): String = try {
        val pm = ctx.packageManager
        pm.getApplicationLabel(pm.getApplicationInfo(pkg, 0)).toString()
    } catch (e: Exception) { pkg }

    /** App senza icona, non di sistema, con almeno 3 permessi sensibili concessi. */
    @Suppress("DEPRECATION")
    fun hiddenSensitive(ctx: Context, pkg: String): Boolean {
        return try {
            val pm = ctx.packageManager
            val p = pm.getPackageInfo(pkg, PackageManager.GET_PERMISSIONS)
            val ai = p.applicationInfo
            if (ai == null || (ai.flags and ApplicationInfo.FLAG_SYSTEM) != 0) false
            else pm.getLaunchIntentForPackage(pkg) == null && SENSITIVE.count { granted(p, it) } >= 3
        } catch (e: Exception) { false }
    }

    @Suppress("DEPRECATION")
    private fun apps(ctx: Context, o: MutableList<Finding>, stalker: Set<String>, online: Boolean) {
        val pm = ctx.packageManager
        val power = ctx.getSystemService(PowerManager::class.java)
        val hidden = mutableListOf<String>(); val side = mutableListOf<String>()
        val known = mutableListOf<String>(); var knownHidden = false
        val overlay = mutableListOf<String>(); var overlayRisk = false
        val inst = mutableListOf<String>(); var instRisk = false
        val batt = mutableListOf<String>(); var battRisk = false
        val mic = mutableListOf<String>()
        val inv = JSONArray(); var sysCount = 0
        for (p in pm.getInstalledPackages(PackageManager.GET_PERMISSIONS)) {
            val ai = p.applicationInfo ?: continue
            val pkg = p.packageName
            if ((ai.flags and ApplicationInfo.FLAG_SYSTEM) != 0) { sysCount++; continue }
            if (pkg == ctx.packageName) continue
            val noIcon = pm.getLaunchIntentForPackage(pkg) == null
            val installer = if (Build.VERSION.SDK_INT >= 30) pm.getInstallSourceInfo(pkg).installingPackageName
                            else pm.getInstallerPackageName(pkg)
            val sideloaded = installer == null || installer !in STORES
            val name = label(ctx, pkg)
            val score = SENSITIVE.count { granted(p, it) }
            inv.put(org.json.JSONObject().put("name", appName(ctx, pkg)).put("pkg", pkg).put("hidden", noIcon)
                .put("store", !sideloaded).put("perms", JSONArray(CODES.filter { granted(p, it.key) }.values.distinct())))
            if (pkg in stalker) { known += name; if (noIcon) knownHidden = true }
            if (noIcon && score >= 4) hidden += "$name [$score permessi sensibili]"
            else if (sideloaded && score >= 5) side += "$name [$score]"
            if (granted(p, "android.permission.SYSTEM_ALERT_WINDOW")) { overlay += name; if (noIcon) overlayRisk = true }
            if (granted(p, "android.permission.REQUEST_INSTALL_PACKAGES")) { inst += name; if (noIcon) instRisk = true }
            if (power?.isIgnoringBatteryOptimizations(pkg) == true) { batt += name; if (noIcon) battRisk = true }
            if (granted(p, "android.permission.RECORD_AUDIO") && granted(p, "android.permission.CAMERA")) mic += name
        }
        lastInventory = inv; lastCounts = inv.length() to sysCount
        val src = if (online) "lista pubblica aggiornata (${stalker.size} app note)" else "lista integrata, senza connessione (${stalker.size} app note)"
        o += if (known.isEmpty()) Finding("stalker", "Nessuna app spia tra quelle note", 0, "Confronto con $src")
             else Finding("stalker", "App presente nella lista delle app di sorveglianza", if (knownHidden) 2 else 1, names(known) + ". Confronto con $src")
        if (hidden.isNotEmpty()) o += Finding("apps_hidden", "App senza icona con molti permessi sensibili", 2, hidden.joinToString("; "))
        if (side.isNotEmpty()) o += Finding("apps_side", "App fuori dagli store con molti permessi", 1, side.joinToString("; "))
        if (hidden.isEmpty() && side.isEmpty()) o += Finding("apps", "Nessuna app sospetta con i criteri usati", 0, "Euristica: non e' un antivirus")
        if (overlay.isNotEmpty()) o += Finding("overlay", "App che possono comparire sopra le altre", if (overlayRisk) 1 else 0, names(overlay))
        if (inst.isNotEmpty()) o += Finding("installer", "App che possono installare altre app", if (instRisk) 1 else 0, names(inst))
        if (batt.isNotEmpty()) o += Finding("battery", "App sempre attive in background", if (battRisk) 1 else 0, names(batt))
        if (mic.isNotEmpty()) o += Finding("mic", "App con microfono e fotocamera", 0, names(mic))
    }

    private fun lock(ctx: Context, o: MutableList<Finding>) {
        val km = ctx.getSystemService(KeyguardManager::class.java)
        o += if (km != null && km.isDeviceSecure) Finding("lock", "Blocco schermo attivo", 0, "PIN, sequenza o password impostati")
             else Finding("lock", "Nessun blocco schermo", 1, "Il telefono si apre senza PIN, sequenza o password")
    }

    private fun root(ctx: Context, o: MutableList<Finding>) {
        val paths = listOf("/system/bin/su", "/system/xbin/su", "/sbin/su", "/system/sd/xbin/su", "/system/app/Superuser.apk", "/vendor/bin/su")
        val found = paths.filter { java.io.File(it).exists() }
        val testKeys = Build.TAGS?.contains("test-keys") == true
        val notes = found + (if (testKeys) listOf("sistema firmato con chiavi di test") else emptyList())
        o += if (notes.isEmpty()) Finding("root", "Telefono senza root", 0, "Nessun segno di root")
             else Finding("root", "Segni di root o sistema modificato", 1, notes.joinToString("; "))
    }

    @Suppress("DEPRECATION")
    private fun fromStore(ctx: Context, pkg: String): Boolean = try {
        val pm = ctx.packageManager
        val inst = if (Build.VERSION.SDK_INT >= 30) pm.getInstallSourceInfo(pkg).installingPackageName else pm.getInstallerPackageName(pkg)
        inst != null && inst in STORES
    } catch (e: Exception) { false }

    private fun keyboards(ctx: Context, o: MutableList<Finding>) {
        val l = components(Settings.Secure.getString(ctx.contentResolver, "enabled_input_methods"))
        val third = l.filter { !isSystem(ctx, it) }
        val risky = third.any { !fromStore(ctx, it) }
        o += if (risky) Finding("keyboard", "Tastiera installata da fuori store", 1, third.joinToString { label(ctx, it) })
             else Finding("keyboard", "Tastiere normali", 0, l.joinToString { label(ctx, it) }.ifEmpty { "nessuna rilevata" })
    }

    private fun patch(ctx: Context, o: MutableList<Finding>) {
        val d = SimpleDateFormat("yyyy-MM-dd", Locale.US).parse(Build.VERSION.SECURITY_PATCH) ?: return
        val months = (System.currentTimeMillis() - d.time) / (30L * 24 * 3600 * 1000)
        o += Finding("patch", "Patch di sicurezza: ${Build.VERSION.SECURITY_PATCH}", if (months > 12) 1 else 0,
            if (months > 12) "Vecchia di $months mesi: vulnerabilita' note non corrette" else "Aggiornata")
    }
}
