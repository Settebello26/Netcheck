package com.netcheck

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Intent
import android.content.pm.ServiceInfo
import android.net.VpnService
import android.os.Build
import android.os.PowerManager
import android.os.SystemClock
import org.json.JSONArray
import org.json.JSONObject
import kotlin.concurrent.thread

/** Esegue la diagnosi in primo piano e ospita la VPN locale "solo DNS". */
class ScanService : VpnService() {
    private val ch = "netcheck"
    private var wake: PowerManager.WakeLock? = null
    private var dns: DnsMonitor? = null

    private fun notif(text: String, tap: PendingIntent? = null): Notification {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(ch, "Diagnosi", NotificationManager.IMPORTANCE_LOW))
        return Notification.Builder(this, ch).setSmallIcon(R.drawable.ic_stat)
            .setContentTitle("NetCheck").setContentText(text).setOnlyAlertOnce(true)
            .setContentIntent(tap ?: PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE))
            .build()
    }

    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
        if (i == null || RunState.running) return START_NOT_STICKY
        val server = i.getStringExtra("s").orEmpty()
        val token = i.getStringExtra("t").orEmpty()
        val pin = i.getStringExtra("fp").orEmpty()
        val vpn = i.getBooleanExtra("vpn", true)
        val n = notif("Diagnosi in corso…")
        if (Build.VERSION.SDK_INT >= 29) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC) else startForeground(1, n)
        wake = getSystemService(PowerManager::class.java).newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "netcheck:run").apply { acquire(25 * 60 * 1000L) }
        RunState.reset(); RunState.running = true
        thread {
            try { work(server, token, pin, vpn) } catch (e: Exception) { RunState.say("Errore: ${e.message}") }
            finally {
                dns?.stop()
                RunState.running = false; RunState.prog("")
                wake?.release()
                stopForeground(STOP_FOREGROUND_REMOVE); stopSelf()
            }
        }
        return START_NOT_STICKY
    }

    override fun onRevoke() { dns?.stop(); super.onRevoke() }

    private fun work(server: String, token: String, pin: String, wantVpn: Boolean) {
        val say = RunState::say
        say("Verifico che la connessione al server non sia intercettata…")
        try { Api.call(server, "/api/ping", pin) } catch (e: Api.PinException) {
            say("🔴 Il certificato del server non corrisponde: la rete sta intercettando l'HTTPS.")
            RunState.alert = "Il certificato visto da questo telefono e' diverso da quello del server. Nessun dato inviato, QR non consumato. Riprova da un'altra rete."
            return
        }
        val cr = Api.call(server, "/api/claim", pin, JSONObject().put("token", token).toString())
        if (cr.code != 200) { say("QR scaduto, gia' usato o non valido."); return }
        val j = JSONObject(cr.body)
        val session = j.getString("session")
        val duration = j.optInt("duration", 600)

        say("Scarico la lista delle app di sorveglianza note…")
        val (iocs, online) = Indicators.load()
        say("Controllo impostazioni e app installate…")
        val findings = Checks.run(this, iocs.packages, online).toMutableList()
        val dnsList = Checks.dnsServers(this)
        val upstream = dnsList.firstOrNull { !it.contains(':') } ?: dnsList.firstOrNull() ?: "8.8.8.8"

        var monitor: DnsMonitor? = null
        if (wantVpn) {
            val pfd = Builder().setSession("NetCheck").addAddress(DnsMonitor.LOCAL, 32)
                .addDnsServer(DnsMonitor.FAKE_DNS).addRoute(DnsMonitor.FAKE_DNS, 32).setBlocking(true).establish()
            if (pfd != null) {
                val m = DnsMonitor(this, upstream) { s -> protect(s) }
                m.start(pfd); monitor = m; dns = m
                say("Analisi dei siti raggiunti dalle app: attiva.")
            } else say("Non e' stato possibile attivare l'analisi dei siti.")
        } else say("Analisi dei siti non attivata (permesso VPN non concesso).")

        val lat = mutableListOf<Long>()
        val ips = linkedSetOf<String>()
        var fails = 0
        var pinBad = false
        val end = SystemClock.elapsedRealtime() + duration * 1000L
        val nm = getSystemService(NotificationManager::class.java)
        while (SystemClock.elapsedRealtime() < end) {
            try {
                val t0 = SystemClock.elapsedRealtime()
                val r = Api.call(server, "/api/ping", pin)
                lat += SystemClock.elapsedRealtime() - t0
                ips += JSONObject(r.body).optString("ip")
            } catch (e: Api.PinException) { pinBad = true } catch (e: Exception) { fails++ }
            val left = (end - SystemClock.elapsedRealtime()) / 1000
            val pct = (100 - left * 100 / duration).toInt().coerceIn(0, 100)
            RunState.prog("Mancano circa ${left / 60 + 1} minuti. Puoi usare il telefono.", pct)
            nm.notify(1, notif("In corso… ${left}s"))
            Thread.sleep(30_000)
        }
        RunState.prog("Preparo il report…", 100)

        var dnsJson = JSONObject()
        val m = monitor
        if (m != null) {
            m.stop()
            val r = m.summary(iocs.domains, iocs.ips) { pkg -> Checks.hiddenSensitive(this, pkg) }
            dnsJson = r.json
            findings += r.findings
        } else findings += Finding("traffic", "Analisi dei siti raggiunti non riuscita", 1, "VPN locale non attivata")

        if (pinBad) findings += Finding("pin", "Certificato del server cambiato durante il test", 2, "Possibile intercettazione HTTPS sulla rete")
        findings += if (ips.size > 2) Finding("ip", "IP pubblico instabile", 1, ips.joinToString())
                    else Finding("ip", "IP pubblico", 0, ips.joinToString())
        val med = lat.sorted().getOrNull(lat.size / 2) ?: -1
        if (med > 800) findings += Finding("lat", "Latenza alta", 1, "$med ms (mediana)")
        if (fails > 3) findings += Finding("fail", "Connessione instabile", 1, "$fails richieste fallite")

        val device = JSONObject().put("model", Build.MODEL).put("brand", Build.MANUFACTURER)
            .put("android", Build.VERSION.RELEASE).put("patch", Build.VERSION.SECURITY_PATCH)
            .put("apps_user", Checks.lastCounts.first).put("apps_system", Checks.lastCounts.second)
        val report = JSONObject().put("device", device)
            .put("findings", JSONArray(findings.map { f -> f.json() }))
            .put("dns", dnsJson).put("apps", Checks.lastInventory)
            .put("ips", JSONArray(ips.toList())).put("latency_median_ms", med).put("vpn_capture", m != null)
        val body = JSONObject().put("session", session).put("report", report).toString()
        val up = try { Api.call(server, "/api/report", pin, body) }
                 catch (e: Api.PinException) { Api.call(server, "/api/report", null, body) }
        if (up.code == 200) {
            val url = server.trimEnd('/') + "/r/" + session
            RunState.reportUrl = url
            History.add(this, url, findings.maxOf { f -> f.level })
            say("✅ Test completato. Il tuo report è pronto.")
            val tap = PendingIntent.getActivity(this, 1, Intent(this, ReportActivity::class.java).putExtra("url", url),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
            nm.notify(2, notif("Report pronto: tocca per vederlo.", tap))
        } else say("Invio del report fallito (codice ${up.code}).")
    }
}
