package com.netcheck

import java.net.URL
import javax.net.ssl.HttpsURLConnection

/** Indicatori pubblici di app/server di sorveglianza (stalkerware). */
class Iocs(val packages: Set<String>, val domains: Set<String>, val ips: Set<String>)

/**
 * Lista pubblica del gruppo Echap: https://github.com/AssoEchap/stalkerware-indicators (non e' completa).
 * Scaricata a ogni test; se offline si usa una copia ridotta di nomi distintivi.
 */
object Indicators {
    private const val IOC_URL = "https://raw.githubusercontent.com/AssoEchap/stalkerware-indicators/master/ioc.yaml"

    private val BUNDLED = setOf(
        "com.thetruth", "com.mxspy", "com.spyzee", "com.ispyoo", "com.hellospy", "com.maxxspy", "com.topspy",
        "net.reptilicus.clientapp", "com.ownspy.android", "com.cocospy", "com.spyic", "com.mspy.lite",
        "med.mspy.mspy", "com.eyezy.android", "com.vvt.android.syncmanager", "pl.lidwin.letmespy",
        "com.xnspy.dashboard", "com.panspy.android", "com.spyhumanrev", "com.meuspy", "com.spy2mobile",
        "com.sap4mobile", "com.thewispy", "com.shadyspy.monitor", "com.chaoqi.spyapp", "com.sl360",
        "com.spytoapp.system", "com.metasploit.stage", "com.androidlost", "com.surebrec", "com.lsdroid.cerberus",
        "com.trackview", "com.droidwatcher", "net.majorkernelpanic.spydroid", "com.spynote.software.stubspynote",
        "com.xhunter.client", "com.realtime.spyapp", "com.mobiletracker", "com.mobiletrackerfree.www",
        "wosc.cwf", "org.traccar.client", "com.imonitor.ainfo", "com.wtspy.apps")

    private val PKG = Regex("^[A-Za-z0-9_.-]{5,}$")
    private val DOM = Regex("^[A-Za-z0-9._-]+\\.[A-Za-z]{2,}$")
    private val IP4 = Regex("^\\d{1,3}(\\.\\d{1,3}){3}$")

    /** Restituisce (indicatori, true se la lista e' stata scaricata online). */
    fun load(): Pair<Iocs, Boolean> = try {
        val c = URL(IOC_URL).openConnection() as HttpsURLConnection
        c.connectTimeout = 8_000; c.readTimeout = 15_000
        val text = try { c.inputStream.use { it.readBytes() }.toString(Charsets.UTF_8) } finally { c.disconnect() }
        val r = parse(text)
        if (r.packages.size < 50) throw IllegalStateException("lista troppo piccola")
        Iocs(r.packages + BUNDLED, r.domains, r.ips) to true
    } catch (e: Exception) { Iocs(BUNDLED, emptySet(), emptySet()) to false }

    private fun value(t: String) = t.substring(2).substringBefore(" #").trim().trim('"', '\'')

    fun parse(text: String): Iocs {
        val pk = HashSet<String>(); val dom = HashSet<String>(); val ips = HashSet<String>()
        var inPk = false; var c2Indent = -1; var mode = ""
        for (line in text.lineSequence()) {
            val t = line.trim()
            if (t.isEmpty() || t.startsWith("#")) continue
            val indent = line.length - line.trimStart().length
            if (c2Indent >= 0 && indent <= c2Indent) { c2Indent = -1; mode = "" }
            if (t == "c2:") { c2Indent = indent; mode = ""; inPk = false; continue }
            if (c2Indent >= 0) {
                if (t == "domains:") mode = "dom"
                else if (t == "ips:") mode = "ip"
                else if (t.startsWith("- ")) {
                    val v = value(t)
                    if (mode == "dom" && DOM.matches(v)) dom += v.lowercase()
                    else if (mode == "ip" && IP4.matches(v)) ips += v
                } else mode = ""
                continue
            }
            if (t == "packages:") { inPk = true; continue }
            if (inPk) {
                if (t.startsWith("- ")) { val v = value(t); if (PKG.matches(v) && v.contains('.')) pk += v }
                else inPk = false
            }
        }
        return Iocs(pk, dom, ips)
    }
}
