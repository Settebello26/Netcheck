package com.netcheck

import android.content.Context
import android.net.ConnectivityManager
import android.os.Build
import android.os.ParcelFileDescriptor
import android.system.OsConstants
import org.json.JSONArray
import org.json.JSONObject
import java.io.FileInputStream
import java.io.FileOutputStream
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress
import java.net.InetSocketAddress
import java.util.concurrent.Executors
import kotlin.concurrent.thread

/**
 * VPN locale "solo DNS": solo le richieste DNS passano da qui, il resto del traffico va per la sua strada.
 * Per ogni app registra quali nomi di siti cerca (mai il contenuto) e confronta con gli indicatori noti.
 */
class DnsMonitor(private val ctx: Context, private val upstream: String, private val protect: (DatagramSocket) -> Boolean) {
    companion object {
        const val LOCAL = "10.111.222.1"
        const val FAKE_DNS = "10.111.222.2"
    }

    class Entry(val label: String, val pkg: String) {
        var queries = 0
        val domains = HashMap<String, Int>()
        val ips = HashSet<String>()
    }

    class Summary(val json: JSONObject, val findings: List<Finding>, val queries: Int)

    private val apps = HashMap<String, Entry>()
    private val pool = Executors.newFixedThreadPool(4)
    @Volatile private var running = false
    private var pfd: ParcelFileDescriptor? = null
    private var total = 0

    fun start(fd: ParcelFileDescriptor) {
        pfd = fd; running = true
        val input = FileInputStream(fd.fileDescriptor)
        val output = FileOutputStream(fd.fileDescriptor)
        thread(isDaemon = true) {
            val buf = ByteArray(32767)
            while (running) {
                val n = try { input.read(buf) } catch (e: Exception) { -1 }
                if (n < 0) break
                if (n < 28) continue
                try { handle(buf.copyOf(n), output) } catch (e: Exception) { }
            }
        }
    }

    fun stop() {
        running = false
        try { pfd?.close() } catch (e: Exception) { }
        pool.shutdownNow()
    }

    private fun u16(b: ByteArray, i: Int) = ((b[i].toInt() and 0xff) shl 8) or (b[i + 1].toInt() and 0xff)
    private fun be32(b: ByteArray, i: Int): Long = (u16(b, i).toLong() shl 16) or u16(b, i + 2).toLong()
    private fun put32(b: ByteArray, i: Int, v: Long) {
        b[i] = (v shr 24).toByte(); b[i + 1] = (v shr 16).toByte(); b[i + 2] = (v shr 8).toByte(); b[i + 3] = v.toByte()
    }

    private fun handle(p: ByteArray, out: FileOutputStream) {
        if ((p[0].toInt() shr 4) != 4) return
        val ihl = (p[0].toInt() and 0xf) * 4
        if (p.size < ihl + 8) return
        val proto = p[9].toInt() and 0xff
        val src = p.copyOfRange(12, 16)
        val dst = p.copyOfRange(16, 20)
        if (proto == 6) {   // TCP verso il finto DNS (es. DNS privato): chiudiamo subito, cosi' Android passa al DNS normale
            val r = rst(p, ihl, src, dst)
            if (r != null) synchronized(out) { out.write(r) }
            return
        }
        if (proto != 17) return
        val sport = u16(p, ihl)
        val dport = u16(p, ihl + 2)
        if (dport != 53) return
        val end = minOf(p.size, ihl + u16(p, ihl + 4))
        if (end <= ihl + 8) return
        val payload = p.copyOfRange(ihl + 8, end)
        val entry = entryFor(ownerUid(src, sport, dst))
        val name = qname(payload)
        synchronized(this) {
            total++; entry.queries++
            if (name != null) entry.domains[name] = (entry.domains[name] ?: 0) + 1
        }
        pool.execute {
            val resp = forward(payload)
            if (resp != null) {
                val ips = answerIps(resp)
                if (ips.isNotEmpty()) synchronized(this) { if (entry.ips.size < 500) entry.ips.addAll(ips) }
                synchronized(out) { out.write(udpPacket(dst, src, sport, resp)) }
            }
        }
    }

    private fun ownerUid(src: ByteArray, sport: Int, dst: ByteArray): Int {
        if (Build.VERSION.SDK_INT < 29) return -1
        return try {
            val cm = ctx.getSystemService(ConnectivityManager::class.java)
            cm.getConnectionOwnerUid(OsConstants.IPPROTO_UDP,
                InetSocketAddress(InetAddress.getByAddress(src), sport),
                InetSocketAddress(InetAddress.getByAddress(dst), 53))
        } catch (e: Exception) { -1 }
    }

    @Suppress("DEPRECATION")
    private fun entryFor(uid: Int): Entry = synchronized(this) {
        val pm = ctx.packageManager
        val pkgs = if (uid >= 0) pm.getPackagesForUid(uid) else null
        val pkg = pkgs?.firstOrNull() ?: ""
        val key = if (pkg.isNotEmpty()) pkg else "uid:$uid"
        apps.getOrPut(key) {
            val label = if (pkg.isNotEmpty()) {
                try { pm.getApplicationLabel(pm.getApplicationInfo(pkg, 0)).toString() + " ($pkg)" } catch (e: Exception) { pkg }
            } else if (uid == 1000) "Sistema Android" else "App non identificata"
            Entry(label, pkg)
        }
    }

    private fun qname(d: ByteArray): String? {
        return try {
            val sb = StringBuilder(); var p = 12
            while (true) {
                val l = d[p].toInt() and 0xff
                if (l == 0) break
                if (l and 0xc0 != 0) return null
                sb.append(String(d, p + 1, l, Charsets.US_ASCII)).append('.')
                p += l + 1
            }
            sb.toString().trimEnd('.').lowercase()
        } catch (e: Exception) { null }
    }

    private fun skipName(d: ByteArray, s: Int): Int {
        var p = s
        while (true) {
            val l = d[p].toInt() and 0xff
            if (l == 0) return p + 1
            if (l and 0xc0 == 0xc0) return p + 2
            p += l + 1
        }
    }

    private fun answerIps(d: ByteArray): List<String> {
        val out = ArrayList<String>()
        try {
            val qd = u16(d, 4); val an = u16(d, 6); var p = 12
            repeat(qd) { p = skipName(d, p) + 4 }
            repeat(an) {
                val ne = skipName(d, p); val type = u16(d, ne); val rl = u16(d, ne + 8); val rd = ne + 10
                if ((type == 1 && rl == 4) || (type == 28 && rl == 16)) {
                    val a = InetAddress.getByAddress(d.copyOfRange(rd, rd + rl)).hostAddress
                    if (a != null) out += a
                }
                p = rd + rl
            }
        } catch (e: Exception) { }
        return out
    }

    private fun forward(q: ByteArray): ByteArray? {
        return try {
            DatagramSocket().use { s ->
                protect(s); s.soTimeout = 4000
                s.connect(InetAddress.getByName(upstream), 53)
                s.send(DatagramPacket(q, q.size))
                val rb = ByteArray(4096); val rp = DatagramPacket(rb, rb.size); s.receive(rp)
                rb.copyOf(rp.length)
            }
        } catch (e: Exception) { null }
    }

    private fun checksum(data: ByteArray, off: Int, len: Int): Int {
        var sum = 0; var i = off
        while (i + 1 < off + len) { sum += ((data[i].toInt() and 0xff) shl 8) or (data[i + 1].toInt() and 0xff); i += 2 }
        if (i < off + len) sum += (data[i].toInt() and 0xff) shl 8
        while ((sum shr 16) != 0) sum = (sum and 0xffff) + (sum shr 16)
        return sum.inv() and 0xffff
    }

    private fun fillIp(b: ByteArray, total: Int, proto: Int, src: ByteArray, dst: ByteArray) {
        b[0] = 0x45; b[2] = (total shr 8).toByte(); b[3] = total.toByte(); b[6] = 0x40; b[8] = 64; b[9] = proto.toByte()
        System.arraycopy(src, 0, b, 12, 4); System.arraycopy(dst, 0, b, 16, 4)
        val ck = checksum(b, 0, 20)
        b[10] = (ck shr 8).toByte(); b[11] = ck.toByte()
    }

    private fun udpPacket(src: ByteArray, dst: ByteArray, dport: Int, payload: ByteArray): ByteArray {
        val total = 28 + payload.size
        val b = ByteArray(total)
        fillIp(b, total, 17, src, dst)
        b[21] = 53; b[22] = (dport shr 8).toByte(); b[23] = dport.toByte()
        val ul = 8 + payload.size
        b[24] = (ul shr 8).toByte(); b[25] = ul.toByte()
        System.arraycopy(payload, 0, b, 28, payload.size)
        return b
    }

    private fun rst(p: ByteArray, ihl: Int, src: ByteArray, dst: ByteArray): ByteArray? {
        if (p.size < ihl + 20) return null
        val flags = p[ihl + 13].toInt() and 0xff
        if ((flags and 0x04) != 0) return null
        val sport = u16(p, ihl); val dport = u16(p, ihl + 2)
        val seqIn = be32(p, ihl + 4); val ackIn = be32(p, ihl + 8)
        val dataOff = ((p[ihl + 12].toInt() and 0xff) shr 4) * 4
        val payload = maxOf(0, p.size - ihl - dataOff)
        val hasAck = (flags and 0x10) != 0
        val syn = if ((flags and 0x02) != 0) 1 else 0
        val fin = if ((flags and 0x01) != 0) 1 else 0
        val ack = (seqIn + payload + syn + fin) and 0xffffffffL
        val b = ByteArray(40)
        fillIp(b, 40, 6, dst, src)
        b[20] = (dport shr 8).toByte(); b[21] = dport.toByte(); b[22] = (sport shr 8).toByte(); b[23] = sport.toByte()
        put32(b, 24, if (hasAck) ackIn else 0L)
        put32(b, 28, if (hasAck) 0L else ack)
        b[32] = 0x50
        b[33] = (if (hasAck) 0x04 else 0x14).toByte()
        val pseudo = ByteArray(32)
        System.arraycopy(dst, 0, pseudo, 0, 4); System.arraycopy(src, 0, pseudo, 4, 4)
        pseudo[9] = 6; pseudo[11] = 20
        System.arraycopy(b, 20, pseudo, 12, 20)
        val ck = checksum(pseudo, 0, 32)
        b[36] = (ck shr 8).toByte(); b[37] = ck.toByte()
        return b
    }

    private fun isIoc(d: String, set: Set<String>): Boolean {
        if (set.isEmpty()) return false
        var s = d
        while (true) {
            if (s in set) return true
            val i = s.indexOf('.')
            if (i < 0) return false
            s = s.substring(i + 1)
        }
    }

    /** Riassunto per il report + eventuali segnali (server di spie noti, app nascoste collegate a internet). */
    fun summary(iocDomains: Set<String>, iocIps: Set<String>, risky: (String) -> Boolean): Summary = synchronized(this) {
        val json = JSONObject(); val out = mutableListOf<Finding>()
        for (e in apps.values) {
            val doms = JSONArray()
            e.domains.entries.sortedByDescending { it.value }.take(40).forEach {
                doms.put(JSONObject().put("host", it.key).put("count", it.value))
            }
            json.put(e.label, JSONObject().put("queries", e.queries).put("domains", doms))
            val bad = e.domains.keys.filter { isIoc(it, iocDomains) }
            val badIps = e.ips.filter { it in iocIps }
            if (bad.isNotEmpty() || badIps.isNotEmpty())
                out += Finding("ioc_dns_" + e.label, "App in contatto con server di spie noti", 2, (bad + badIps).take(6).joinToString())
            else if (e.pkg.isNotEmpty() && risky(e.pkg))
                out += Finding("hidden_net_" + e.label, "App nascosta con permessi sensibili collegata a internet", 1, "${e.queries} ricerche di siti")
        }
        if (total == 0) out += Finding("traffic", "Analisi dei siti raggiunti non riuscita", 1, "Nessuna ricerca di siti osservata")
        else out += Finding("traffic", "Analisi dei siti raggiunti eseguita", 0, "$total ricerche da ${apps.size} app")
        Summary(json, out, total)
    }
}
