package com.netcheck

import android.Manifest
import android.content.ClipboardManager
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.net.VpnService
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.journeyapps.barcodescanner.ScanContract
import com.journeyapps.barcodescanner.ScanOptions
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : AppCompatActivity() {
    private val navy = Color.parseColor("#0B1F3A")
    private val teal = Color.parseColor("#0E8A94")
    private val bgColor = Color.parseColor("#F3F6F9")
    private val ink = Color.parseColor("#1F2A37")
    private val muted = Color.parseColor("#6B7280")

    private lateinit var scanBtn: Button
    private lateinit var pasteBtn: Button
    private lateinit var reportBtn: Button
    private lateinit var statusCard: LinearLayout
    private lateinit var statusTitle: TextView
    private lateinit var bar: ProgressBar
    private lateinit var barText: TextView
    private lateinit var logView: TextView
    private var pending: Array<String>? = null

    private val scan = registerForActivityResult(ScanContract()) { r -> r.contents?.let(::onQr) }
    private val vpnResult = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        startScan(r.resultCode == RESULT_OK)
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun shape(color: Int, radius: Int, stroke: Int = 0) = GradientDrawable().apply {
        setColor(color); cornerRadius = dp(radius).toFloat(); if (stroke != 0) setStroke(dp(2), stroke)
    }

    private fun lp(top: Int = 12) = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
        .apply { setMargins(dp(16), dp(top), dp(16), 0) }

    private fun label(s: String, size: Float, color: Int, bold: Boolean = false) = TextView(this).apply {
        text = s; textSize = size; setTextColor(color); if (bold) setTypeface(typeface, Typeface.BOLD)
    }

    private fun card() = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL; background = shape(Color.WHITE, 16)
        setPadding(dp(18), dp(16), dp(18), dp(16)); elevation = dp(2).toFloat(); layoutParams = lp()
    }

    private fun button(s: String, primary: Boolean, click: () -> Unit) = Button(this).apply {
        text = s; isAllCaps = false; textSize = 16f; stateListAnimator = null
        setTextColor(if (primary) Color.WHITE else teal)
        background = if (primary) shape(teal, 14) else shape(Color.WHITE, 14, teal)
        layoutParams = lp(12).apply { height = dp(54) }
        setOnClickListener { click() }
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        window.statusBarColor = navy
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(bgColor) }

        val hero = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL
            val r = dp(28).toFloat()
            background = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(navy, teal))
                .apply { cornerRadii = floatArrayOf(0f, 0f, 0f, 0f, r, r, r, r) }
            setPadding(dp(20), dp(40), dp(20), dp(28))
        }
        hero.addView(ImageView(this).apply { setImageResource(R.drawable.ic_launcher_foreground) },
            LinearLayout.LayoutParams(dp(110), dp(110)))
        hero.addView(label("NetCheck", 28f, Color.WHITE, true))
        hero.addView(label("Controllo di sicurezza del telefono", 15f, Color.parseColor("#CFE9EC")))
        col.addView(hero, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT))

        val how = card()
        how.addView(label("Come funziona", 18f, ink, true))
        listOf("1️⃣  Scansiona il QR (o incolla il link) che ti hanno dato",
            "2️⃣  Leggi il consenso: puoi anche dire di no",
            "3️⃣  Aspetta 10 minuti: puoi usare il telefono",
            "4️⃣  Ricevi subito il tuo report, spiegato in modo semplice").forEach {
            how.addView(label(it, 15f, ink).apply { setPadding(0, dp(8), 0, 0) })
        }
        col.addView(how)

        scanBtn = button("📷   Scansiona il QR", true) { scanQr() }
        pasteBtn = button("🔗   Ho un link", false) { pasteLink() }
        col.addView(scanBtn); col.addView(pasteBtn)

        statusCard = card().apply { visibility = View.GONE }
        statusTitle = label("", 18f, ink, true)
        bar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = 100; progressTintList = ColorStateList.valueOf(teal)
        }
        barText = label("", 14f, muted)
        logView = label("", 13f, muted).apply { setPadding(0, dp(10), 0, 0) }
        statusCard.addView(statusTitle)
        statusCard.addView(bar, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(10)).apply { topMargin = dp(10) })
        statusCard.addView(barText)
        statusCard.addView(logView)
        col.addView(statusCard)

        reportBtn = button("📄   Apri il tuo report", true) { openReport() }.apply { visibility = View.GONE }
        col.addView(reportBtn)
        val links = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER; setPadding(0, dp(16), 0, 0) }
        links.addView(label("🕑 I miei report", 14f, teal, true).apply { setPadding(dp(14), dp(8), dp(14), dp(8)); setOnClickListener { showHistory() } })
        links.addView(label("🔒 Privacy", 14f, teal, true).apply { setPadding(dp(14), dp(8), dp(14), dp(8)); setOnClickListener { showPrivacy() } })
        col.addView(links)
        col.addView(label("NetCheck non è un antivirus: segnala indizi, non prova che un telefono sia pulito.", 12f, muted)
            .apply { setPadding(dp(24), dp(18), dp(24), dp(28)); gravity = Gravity.CENTER })
        setContentView(ScrollView(this).apply { isFillViewport = true; setBackgroundColor(bgColor); addView(col) })

        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED)
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        handleIntent(intent)
    }

    override fun onNewIntent(i: Intent) { super.onNewIntent(i); handleIntent(i) }

    private fun handleIntent(i: Intent?) {
        i?.data?.takeIf { it.scheme == "netcheck" }?.let { onQr(it.toString()); i.data = null }
    }

    override fun onResume() {
        super.onResume()
        RunState.onChange = { runOnUiThread { refresh() } }
        refresh()
    }

    override fun onPause() { RunState.onChange = null; super.onPause() }

    private fun refresh() {
        val running = RunState.running
        val text = synchronized(RunState.log) { RunState.log.toString() }
        statusCard.visibility = if (running || text.isNotEmpty()) View.VISIBLE else View.GONE
        statusTitle.text = if (running) "⏳  Test in corso" else if (RunState.reportUrl != null) "✅  Test completato" else "ℹ️  Ultimo test"
        bar.visibility = if (running) View.VISIBLE else View.GONE
        barText.visibility = if (running) View.VISIBLE else View.GONE
        barText.text = RunState.progress
        bar.progress = RunState.pct
        logView.text = text
        scanBtn.isEnabled = !running; pasteBtn.isEnabled = !running
        reportBtn.visibility = if (RunState.reportUrl != null) View.VISIBLE else View.GONE
        RunState.alert?.let {
            RunState.alert = null
            AlertDialog.Builder(this).setTitle("Rete sospetta").setMessage(it).setPositiveButton("OK", null).show()
        }
        if (RunState.reportUrl != null && !RunState.reportOpened) { RunState.reportOpened = true; openReport() }
    }

    private fun openReport() {
        startActivity(Intent(this, ReportActivity::class.java).putExtra("url", RunState.reportUrl))
    }

    private fun scanQr() = scan.launch(ScanOptions().setDesiredBarcodeFormats(ScanOptions.QR_CODE)
        .setPrompt("Inquadra il QR di NetCheck").setBeepEnabled(false).setOrientationLocked(false))

    private fun pasteLink() {
        val et = EditText(this)
        val clip = (getSystemService(CLIPBOARD_SERVICE) as ClipboardManager).primaryClip?.getItemAt(0)?.text?.toString()
        if (clip?.startsWith("netcheck://") == true) et.setText(clip)
        AlertDialog.Builder(this).setTitle("Incolla il link").setView(et)
            .setPositiveButton("OK") { _, _ -> onQr(et.text.toString().trim()) }
            .setNegativeButton("Annulla", null).show()
    }

    private fun onQr(c: String) {
        val u = Uri.parse(c)
        val server = u.getQueryParameter("s").orEmpty()
        val token = u.getQueryParameter("t").orEmpty()
        val pin = u.getQueryParameter("fp").orEmpty().lowercase()
        if (u.scheme != "netcheck" || !server.startsWith("https://") || token.isEmpty()) {
            Toast.makeText(this, "QR non valido", Toast.LENGTH_LONG).show(); return
        }
        AlertDialog.Builder(this).setTitle("Consenso")
            .setMessage("Per circa 10 minuti NetCheck:\n\n" +
                "• controlla certificati, proxy, VPN, DNS, amministratori, accessibilità, notifiche, ADB e le app installate;\n" +
                "• con una VPN locale (Android ti chiederà il permesso) guarda a quali siti cercano di collegarsi le app. Nessun dato passa da server esterni e non vede mai il contenuto.\n\n" +
                "Non legge messaggi, foto o password. Il report viene mostrato a te e inviato anche a chi ti ha dato il QR (${Uri.parse(server).host}).\n\n" +
                "Acconsenti?")
            .setPositiveButton("Acconsento") { _, _ ->
                pending = arrayOf(server, token, pin)
                val prep = VpnService.prepare(this)
                if (prep != null) vpnResult.launch(prep) else startScan(true)
            }
            .setNegativeButton("Annulla", null).show()
    }

    private fun showHistory() {
        val items = History.list(this)
        if (items.isEmpty()) { Toast.makeText(this, "Nessun report salvato su questo telefono", Toast.LENGTH_LONG).show(); return }
        val fmt = SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.ITALY)
        val names = items.map { (if (it.level >= 2) "🔴 " else if (it.level == 1) "🟡 " else "🟢 ") + fmt.format(Date(it.ts)) }.toTypedArray()
        AlertDialog.Builder(this).setTitle("I miei report")
            .setItems(names) { _, which -> startActivity(Intent(this, ReportActivity::class.java).putExtra("url", items[which].url)) }
            .setNegativeButton("Chiudi", null).show()
    }

    private fun showPrivacy() {
        AlertDialog.Builder(this).setTitle("Privacy: cosa raccoglie NetCheck")
            .setMessage("Solo se acconsenti, per 10 minuti:\n\n" +
                "• impostazioni di sicurezza del telefono e elenco delle app installate (nome, permessi delicati, se hanno icona);\n" +
                "• i nomi dei siti che le app cercano di raggiungere (mai il contenuto);\n" +
                "• modello e versione di Android, indirizzo internet pubblico.\n\n" +
                "NON legge messaggi, foto, password, contatti o posizione.\n\n" +
                "Il report lo vedi tu e chi ti ha dato il QR; resta salvato finché lui non lo elimina.")
            .setPositiveButton("OK", null).show()
    }

    private fun startScan(vpn: Boolean) {
        val p = pending ?: return
        startForegroundService(Intent(this, ScanService::class.java)
            .putExtra("s", p[0]).putExtra("t", p[1]).putExtra("fp", p[2]).putExtra("vpn", vpn))
    }
}
