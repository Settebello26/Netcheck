package com.netcheck

import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.print.PrintAttributes
import android.print.PrintManager
import android.view.Gravity
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity

/** Mostra il report completo dentro l'app (pagina del server, senza JavaScript). */
class ReportActivity : AppCompatActivity() {
    private lateinit var web: WebView

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val url = intent.getStringExtra("url") ?: RunState.reportUrl
        if (url == null) { finish(); return }
        val host = Uri.parse(url).host
        window.statusColor()
        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            setBackgroundColor(Color.parseColor("#0B1F3A")); setPadding(dp(8), dp(8), dp(8), dp(8))
        }
        bar.addView(headerButton("←") { finish() })
        bar.addView(TextView(this).apply { text = "Il tuo report"; setTextColor(Color.WHITE); textSize = 18f },
            LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        bar.addView(headerButton("PDF") { savePdf() })
        bar.addView(headerButton("Condividi") { share(url) })
        web = WebView(this).apply {
            settings.javaScriptEnabled = false
            webViewClient = object : WebViewClient() {
                override fun shouldOverrideUrlLoading(v: WebView, r: WebResourceRequest): Boolean = r.url.host != host
            }
            loadUrl(url)
        }
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(bar)
        root.addView(web, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f))
        setContentView(root)
    }

    private fun android.view.Window.statusColor() { statusBarColor = Color.parseColor("#0B1F3A") }

    private fun headerButton(t: String, f: () -> Unit) = Button(this).apply {
        text = t; isAllCaps = false; setTextColor(Color.WHITE); setBackgroundColor(Color.TRANSPARENT)
        setOnClickListener { f() }
    }

    private fun savePdf() {
        val pm = getSystemService(Context.PRINT_SERVICE) as PrintManager
        pm.print("Report NetCheck", web.createPrintDocumentAdapter("Report NetCheck"), PrintAttributes.Builder().build())
    }

    private fun share(url: String) {
        AlertDialog.Builder(this).setTitle("Condividi il report")
            .setMessage("Chiunque abbia il link potrà leggere il report. Vuoi continuare?")
            .setPositiveButton("Condividi") { _, _ ->
                val i = Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, "Il mio report NetCheck: $url")
                startActivity(Intent.createChooser(i, "Condividi il report"))
            }
            .setNegativeButton("Annulla", null).show()
    }
}
