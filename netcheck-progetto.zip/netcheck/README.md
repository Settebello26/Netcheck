# NetCheck

QR monouso -> diagnosi di 10 minuti (con consenso) -> report verde/giallo/rosso.
Funziona anche su GrapheneOS e CalyxOS (nessuna dipendenza da Google Play Services).

## Backend
    cd backend && python -m venv .venv && . .venv/bin/activate && pip install -r requirements.txt
    export ADMIN_PASSWORD='...' PUBLIC_URL='https://netcheck.tuodominio.it' TRUST_PROXY=1
    export SERVER_PUBKEY_SHA256=$(openssl s_client -connect netcheck.tuodominio.it:443 </dev/null 2>/dev/null \
      | openssl x509 -pubkey -noout | openssl pkey -pubin -outform der | openssl dgst -sha256 -hex | awk '{print $2}')
    gunicorn -w 2 -b 127.0.0.1:8000 app:app
Metti davanti un reverse proxy HTTPS (es. Caddy: `netcheck.tuodominio.it { reverse_proxy 127.0.0.1:8000 }`).
Per far restare stabile il pin al rinnovo del certificato, riusa la stessa chiave (certbot `--reuse-key`).
Test: `PYTHONPATH=. python test_flow.py` (serve `pip install qrcode[pil]`, oppure usa uno stub).

## App Android
Apri `android/` in Android Studio, Build > APK, copia l'APK in `backend/static/netcheck.apk`
(scaricabile da `https://tuodominio/static/netcheck.apk`). Per l'analisi del traffico installa PCAPdroid.

## Novita' rispetto alla v1
- Pinning della chiave del server: se la rete intercetta l'HTTPS, l'app lo dice e non invia nulla.
- Token e sessioni salvati solo come hash; claim atomico (uso singolo anche con richieste simultanee).
- Admin: CSRF, rate limit sul login, cookie Strict/Secure, CSP, elimina diagnosi, stati (in attesa / in corso / interrotta / completata / scaduta).
- Controlli aggiuntivi: app senza icona con molti permessi, app fuori store, proxy per rete, DNS privato, ADB wireless, patch di sicurezza vecchie.
- Il QR si consuma solo dopo il consenso; l'app mostra all'utente cosa e' stato inviato.
- Traffico per app con nome del sito (SNI/DNS), HTTP in chiaro, DNS esterni, upload su porte insolite.

## Limiti
Non e' un antivirus. Un IP/DNS diverso puo' essere normale. PCAPdroid sostituisce per 10 minuti un'altra VPN attiva.
