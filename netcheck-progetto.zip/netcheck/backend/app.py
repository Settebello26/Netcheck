"""NetCheck backend: QR monouso -> diagnosi di rete con consenso -> report verde/giallo/rosso."""
import os, io, time, json, base64, secrets, hashlib, hmac, sqlite3
from datetime import datetime
from urllib.parse import urlencode
from functools import wraps
from flask import (Flask, request, session, redirect, abort, jsonify, g,
                   render_template_string)
from jinja2 import DictLoader
import qrcode
from kb import view as build_view, human

DB = os.environ.get("NETCHECK_DB", "netcheck.db")
ADMIN_PASSWORD = os.environ.get("ADMIN_PASSWORD") or ""
PUBLIC_URL = os.environ.get("PUBLIC_URL", "").rstrip("/")
PIN = os.environ.get("SERVER_PUBKEY_SHA256", "").replace(":", "").lower()
TTL = 72 * 3600          # validita' del QR
DURATION = 600           # durata diagnosi (s)
GRACE = 1800             # margine per l'invio del report

app = Flask(__name__)
if not ADMIN_PASSWORD:
    raise SystemExit("Imposta la variabile ADMIN_PASSWORD")
app.secret_key = os.environ.get("SECRET_KEY") or secrets.token_hex(32)
app.config.update(
    MAX_CONTENT_LENGTH=512 * 1024, SESSION_COOKIE_HTTPONLY=True,
    SESSION_COOKIE_SAMESITE="Strict",
    SESSION_COOKIE_SECURE=os.environ.get("INSECURE_COOKIES") != "1")
if os.environ.get("TRUST_PROXY") == "1":
    from werkzeug.middleware.proxy_fix import ProxyFix
    app.wsgi_app = ProxyFix(app.wsgi_app, x_for=1, x_proto=1, x_host=1)

# ---------- db ----------
def db():
    if "db" not in g:
        g.db = sqlite3.connect(DB)
        g.db.row_factory = sqlite3.Row
        g.db.execute("""CREATE TABLE IF NOT EXISTS diag(
            id INTEGER PRIMARY KEY, label TEXT, token_hash TEXT UNIQUE,
            created INT, expires INT, claimed_at INT, session_hash TEXT,
            claimed_ip TEXT, report_json TEXT, verdict TEXT, reported_at INT)""")
    return g.db

@app.teardown_appcontext
def close_db(_):
    d = g.pop("db", None)
    if d:
        d.commit(); d.close()

def now(): return int(time.time())
def hs(x): return hashlib.sha256(x.encode()).hexdigest()
def fmt(t): return datetime.fromtimestamp(t).strftime("%d/%m/%Y %H:%M") if t else "-"

def status(r):
    if r["report_json"]: return "completata"
    if r["claimed_at"]:
        return "in corso" if now() < r["claimed_at"] + DURATION + GRACE else "interrotta"
    return "in attesa" if now() < r["expires"] else "scaduta"

app.jinja_env.globals.update(fmt=fmt, status=status)
app.jinja_env.filters['human'] = human

# ---------- sicurezza ----------
FAILS = {}
def login_required(f):
    @wraps(f)
    def w(*a, **k):
        if not session.get("admin"):
            return redirect("/login")
        return f(*a, **k)
    return w

def csrf_ok():
    return hmac.compare_digest(request.form.get("csrf", ""), session.get("csrf", "x"))

@app.after_request
def headers(r):
    r.headers["X-Content-Type-Options"] = "nosniff"
    r.headers["Cache-Control"] = "no-store"
    r.headers["Content-Security-Policy"] = "default-src 'none'; img-src 'self' data:; style-src 'unsafe-inline'; form-action 'self'"
    return r

# ---------- template ----------
app.jinja_loader = DictLoader({
"base.html": """<!doctype html><html lang=it><meta charset=utf-8>
<meta name=viewport content="width=device-width,initial-scale=1"><title>NetCheck</title>
<style>body{font:16px system-ui;max-width:860px;margin:2rem auto;padding:0 1rem;color:#222}
table{border-collapse:collapse;width:100%}td,th{border-bottom:1px solid #ddd;padding:.5rem;text-align:left;vertical-align:top}
.b{padding:.15rem .6rem;border-radius:1rem;color:#fff;font-weight:600;font-size:.85rem}
.green{background:#2e9d4a}.yellow{background:#d9a400}.red{background:#c62828}.none{background:#777}
.hero{padding:1rem 1.2rem;border-radius:.8rem;color:#fff}.hero p{margin:.4rem 0 0}
.card{border:1px solid #ddd;border-left:6px solid #2e9d4a;border-radius:.6rem;padding:.6rem 1rem;margin:.6rem 0}
.card.l1{border-left-color:#d9a400}.card.l2{border-left-color:#c62828}.card h4{margin:.2rem 0}.card p{margin:.3rem 0}
.hero .big{font-size:2.4rem}.hero.green{background:linear-gradient(135deg,#1e7a3a,#2e9d4a)}
.hero.yellow{background:linear-gradient(135deg,#a87c00,#d9a400)}.hero.red{background:linear-gradient(135deg,#8f1b1b,#c62828)}
.chips span{display:inline-block;background:rgba(255,255,255,.22);border-radius:1rem;padding:.15rem .7rem;margin:.5rem .3rem 0 0;font-size:.85rem}
.tag{display:inline-block;border-radius:.4rem;padding:0 .4rem;font-size:.75rem;margin-right:.2rem;background:#eee}.tag.w{background:#fde7e7;color:#a11}.tag.g{background:#e3f5e8;color:#186a2e}
.safety{background:#fff3f3;border:1px solid #c62828;padding:.7rem 1rem;border-radius:.6rem}
details{margin:.3rem 0}summary{cursor:pointer;color:#555}
input,button{font:inherit;padding:.5rem}button{cursor:pointer}small{color:#666}code{word-break:break-all}</style>
{% block head %}<h1><a href="/" style="color:inherit;text-decoration:none">NetCheck</a></h1>{% endblock %}{% block c %}{% endblock %}""",
"login.html": """{% extends 'base.html' %}{% block c %}<form method=post>
<input type=password name=password placeholder=Password autofocus>
<input type=hidden name=csrf value="{{csrf}}"><button>Entra</button></form>{% if err %}<p>{{err}}</p>{% endif %}{% endblock %}""",
"index.html": """{% extends 'base.html' %}{% block c %}
<form method=post action=/new><input name=label placeholder="Etichetta (es. telefono di Marco)" required maxlength=80 size=36>
<input type=hidden name=csrf value="{{csrf}}"><button>Genera QR monouso</button></form>
<h3>Diagnosi</h3><table><tr><th>Etichetta<th>Creata<th>Stato<th>Esito</tr>
{% for r in rows %}<tr><td><a href="/d/{{r.id}}">{{r.label}}</a><td>{{fmt(r.created)}}<td>{{status(r)}}
<td>{% if r.verdict %}<span class="b {{r.verdict}}">{{r.verdict|upper}}</span>{% endif %}</tr>{% endfor %}</table>
<p><a href=/logout>Esci</a></p>{% endblock %}""",
"qr.html": """{% extends 'base.html' %}{% block c %}<h3>{{label}}</h3>
<p>Mostra questo QR <b>una sola volta</b>: non e' piu' recuperabile dopo aver lasciato la pagina. Vale una diagnosi, scade tra 72 ore.</p>
<img src="data:image/png;base64,{{img}}" width=320 height=320>
<h4>Messaggio da mandare al cliente</h4><p><small>Tieni premuto sul testo, scegli «Seleziona tutto» e poi «Copia». Il link apre una pagina con le istruzioni.</small></p>
<textarea readonly rows=6 style="width:100%">{{message}}</textarea>
<p>Dallo stesso telefono? Copia questo link e incollalo in NetCheck (pulsante "Ho un link"):</p>
<p><a href="{{link}}">Apri direttamente in NetCheck (solo da questo telefono)</a></p>
<textarea readonly rows=5 style="width:100%">{{link}}</textarea>
{% if not pinned %}<p><small>Attenzione: SERVER_PUBKEY_SHA256 non impostato, il controllo anti-intercettazione sul server e' disattivato.</small></p>{% endif %}
<p><a href=/>Indietro</a></p>{% endblock %}""",
"dl.html": """{% extends 'base.html' %}{% block c %}<h3>Scarica NetCheck (Android)</h3>
<p>NetCheck fa una diagnosi di rete di 10 minuti <b>solo se acconsenti</b>. Non legge messaggi, foto o contenuti.</p>
<ol><li><a href="/static/netcheck.apk">Scarica l'app (APK)</a></li>
<li>Aprila e, se Android lo chiede, consenti l'installazione da questa fonte (su Samsung: disattiva temporaneamente Blocco automatico).</li>
<li>Facoltativo ma consigliato: installa PCAPdroid (Play Store o F-Droid) per l'analisi del traffico.</li>
<li>Quando ricevi il tuo QR o link personale: inquadra il QR con la fotocamera oppure copia il link e usa "Ho un link" in NetCheck.</li></ol>
<p><small>Ogni QR vale una sola diagnosi e scade dopo 72 ore.</small></p>{% endblock %}""",
"open.html": """{% extends 'base.html' %}{% block head %}<h1>NetCheck</h1>{% endblock %}{% block c %}
{% if ok %}<div class="hero green"><b style="font-size:1.2rem">Il tuo controllo è pronto</b><p>Controllo di sicurezza del telefono in 10 minuti, solo con il tuo consenso.</p></div>
<ol><li>Se non hai ancora l'app, <a href="/static/netcheck.apk"><b>scaricala qui</b></a> e installala (se Android avvisa che è sconosciuta, scegli «Installa comunque»).</li>
<li>Poi tocca il pulsante:</li></ol>
<p><a href="{{link}}" style="display:block;text-align:center;background:#0E8A94;color:#fff;padding:1rem;border-radius:.8rem;text-decoration:none;font-weight:600">Apri NetCheck</a></p>
<p><small>Questo link vale per un solo controllo. <a href="/privacy">Cosa raccoglie NetCheck</a></small></p>
{% else %}<div class="hero red"><b style="font-size:1.2rem">Link scaduto o già usato</b><p>Chiedi a chi te lo ha dato un link nuovo.</p></div>{% endif %}{% endblock %}""",
"privacy.html": """{% extends 'base.html' %}{% block head %}<h1>NetCheck</h1>{% endblock %}{% block c %}<h2>Privacy: cosa raccoglie NetCheck</h2>
<p>NetCheck fa un controllo di sicurezza del telefono di 10 minuti <b>solo se acconsenti</b>. Puoi rifiutare in qualsiasi momento prima di iniziare.</p>
<h3>Cosa raccoglie</h3><ul>
<li>Modello del telefono, versione di Android e data degli aggiornamenti di sicurezza.</li>
<li>Impostazioni di sicurezza: certificati, proxy, VPN, DNS, amministratori del dispositivo, accessibilità, lettura delle notifiche, tastiere, debug, blocco schermo, segni di root.</li>
<li>Elenco delle app installate: nome, identificativo, se hanno un'icona, da dove sono state installate e quali permessi delicati hanno (microfono, fotocamera, posizione, SMS, contatti, chiamate, stato del telefono).</li>
<li>I <b>nomi dei siti</b> che le app hanno cercato di raggiungere durante il test, con il numero di volte. I nomi dei siti possono rivelare abitudini: per questo li vede solo chi ti ha dato il QR.</li>
<li>L'indirizzo internet pubblico e la velocità di risposta del server.</li></ul>
<h3>Cosa NON raccoglie</h3><ul>
<li>Il contenuto di messaggi, email, foto, file o password.</li>
<li>Le pagine che visiti, i contatti, la posizione. Non usa microfono né fotocamera (tranne la fotocamera per leggere il QR).</li>
<li>Il contenuto del traffico: la VPN locale vede solo le richieste di nomi di siti (DNS), e tutto resta tra il telefono e il server.</li></ul>
<h3>Chi lo vede e per quanto</h3>
<p>Il report viene mostrato a te a fine test e a chi gestisce il servizio e ti ha dato il QR. Resta salvato finché chi gestisce il servizio non lo elimina: chiedi a lui la cancellazione.</p>
<h3>Altro</h3>
<p>Durante il test l'app scarica da GitHub una lista pubblica di app e server di sorveglianza noti (nessun tuo dato viene inviato a GitHub). NetCheck non è un antivirus: segnala indizi, non prova che un telefono sia pulito o infetto.</p>{% endblock %}""",
"report.html": """{% macro card(x) %}<div class="card l{{x.level}}"><h4>{{x.title}}</h4>
<p><b>Cosa significa:</b> {{x.explain}}</p>{% if x.action %}<p><b>Cosa fare:</b> {{x.action}}</p>{% endif %}
{% if x.detail %}<details><summary>Dettagli tecnici</summary><small>{{x.detail}}</small></details>{% endif %}</div>{% endmacro %}
{% set PI = {'mic':'🎤','cam':'📷','loc':'📍','bgloc':'📍⏱','sms':'💬','contacts':'👥','calls':'📞','phone':'📱'} %}
{% set bad = v.cards|selectattr('level','equalto',2)|list %}{% set mid = v.cards|selectattr('level','equalto',1)|list %}{% set ok = v.cards|selectattr('level','equalto',0)|list %}
{% set icon = {'green':'🟢','yellow':'🟡','red':'🔴'}.get(r.verdict, '⚪') %}
<div class="hero {{r.verdict}}"><div class="big">{{icon}}</div><b style="font-size:1.25rem">{{v.headline}}</b><p>{{v.intro}}</p>
<div class="chips"><span>{{bad|length}} importanti</span><span>{{mid|length}} da guardare</span><span>{{ok|length}} a posto</span></div></div>
<p><small>📱 {{rep.device.get('brand','')}} {{rep.device.get('model','?')}} · Android {{rep.device.get('android','?')}} · aggiornamenti di sicurezza: {{rep.device.get('patch','?')}} · app controllate: {{rep.device.get('apps_user','?')}} (più {{rep.device.get('apps_system','?')}} di sistema) · test del {{fmt(r.reported_at)}}</small></p>
{% if v.todo %}<h3>Cosa fare adesso</h3><ol>{% for a in v.todo %}<li>{{a}}</li>{% endfor %}</ol>{% endif %}
{% if v.safety_show %}<div class="safety"><b>Se temi che qualcuno ti controlli</b><p>{{v.safety}}</p></div>{% endif %}
{% if bad %}<h3>🔴 Da controllare subito ({{bad|length}})</h3>{% for x in bad %}{{card(x)}}{% endfor %}{% endif %}
{% if mid %}<h3>🟡 Da guardare ({{mid|length}})</h3>{% for x in mid %}{{card(x)}}{% endfor %}{% endif %}
{% if ok %}<h3>🟢 Tutto a posto ({{ok|length}} controlli)</h3><details><summary>Mostra i controlli</summary>{% for x in ok %}{{card(x)}}{% endfor %}</details>{% endif %}
<h3>🌐 Con chi parlano le app</h3>
{% if v.dns_apps %}<p><small>Per ogni app vedi quali siti ha cercato di raggiungere durante il test (mai il contenuto, solo i nomi). Un'app con molti siti non è per forza un problema: social, giochi e browser ne usano tanti.</small></p>
{% for name, d in v.dns_apps %}<details><summary><b>{{name}}</b> · {{d.queries}} ricerche</summary><ul>{% for x in d.domains %}<li>{{x.host}} <small>({{x.count}})</small></li>{% endfor %}</ul></details>{% endfor %}
{% else %}<p>Questa parte non è stata eseguita (serve il permesso VPN durante il test).</p>{% endif %}
<h3>📲 App installate ({{v.apps|length}})</h3>
{% if v.apps %}<p><small>Permessi che l'app può usare: 🎤 microfono · 📷 fotocamera · 📍 posizione · 💬 SMS · 👥 contatti · 📞 chiamate · 📱 stato del telefono. «Nascosta» = senza icona nel menu. «Fuori store» = non installata da Play Store o simili. In cima le app da guardare per prime.</small></p>
<details><summary><b>Mostra l'elenco completo</b></summary><table>{% for a in v.apps %}<tr><td>{{a.name}}<br><small>{{a.pkg}}</small><td>{% if a.hidden %}<span class="tag w">nascosta</span>{% endif %}{% if not a.store %}<span class="tag w">fuori store</span>{% else %}<span class="tag g">da store</span>{% endif %}<br>{% for p in a.perms %}{{PI.get(p,'')}} {% endfor %}</tr>{% endfor %}</table></details>
{% else %}<p>Elenco non disponibile.</p>{% endif %}
<h3>📶 Rete</h3><p>Indirizzi internet visti: {{rep.ips|join(', ')}}<br>Velocità di risposta: {{rep.get('latency_median_ms','?')}} millisecondi (più è basso, meglio è)</p>
<details><summary><b>Parole difficili</b></summary><dl>{% for t, d in v.glossario %}<dt><b>{{t}}</b></dt><dd>{{d}}</dd>{% endfor %}</dl></details>
<p><small><b>Come leggere questo report.</b> Verde: nulla da segnalare. Giallo: da guardare, spesso innocuo. Rosso: da controllare subito. Questo non è un antivirus: segnala indizi, non prova che un telefono sia pulito o infetto.</small></p>""",
"detail.html": """{% extends 'base.html' %}{% block c %}<h2>{{r.label}}</h2>
{% if rep %}{% include 'report.html' %}{% else %}<p>Stato: {{status(r)}}. Il report arriverà quando il test è concluso.</p>{% endif %}
<form method=post action="/d/{{r.id}}/delete" onsubmit="return confirm('Eliminare?')"><input type=hidden name=csrf value="{{csrf}}"><button>Elimina</button></form>{% endblock %}""",
"client.html": """{% extends 'base.html' %}{% block head %}<h1>NetCheck</h1>{% endblock %}{% block c %}{% include 'report.html' %}
<p><small>Questo report è visibile a chi ha il link personale del test e a chi ti ha dato il QR.</small></p>{% endblock %}"""})

# ---------- admin ----------
@app.route("/a/<token>")
def open_link(token):
    r = db().execute("SELECT * FROM diag WHERE token_hash=?", (hs(token),)).fetchone()
    ok = bool(r) and not r["claimed_at"] and now() < r["expires"]
    server = PUBLIC_URL or request.host_url.rstrip("/")
    link = "netcheck://c?" + urlencode({"s": server, "t": token, "fp": PIN}) if ok else ""
    return render_template_string("{% extends 'open.html' %}", ok=ok, link=link)

@app.route("/privacy")
def privacy():
    return render_template_string("{% extends 'privacy.html' %}")

@app.route("/scarica")
def scarica():
    return render_template_string("{% extends 'dl.html' %}")

@app.route("/login", methods=["GET", "POST"])
def login():
    session.setdefault("csrf", secrets.token_hex(16))
    err = None
    if request.method == "POST":
        ip = request.remote_addr
        n, t0 = FAILS.get(ip, (0, now()))
        if now() - t0 > 900: n, t0 = 0, now()
        if n >= 5:
            err = "Troppi tentativi, riprova piu' tardi."
        elif csrf_ok() and hmac.compare_digest(request.form.get("password", ""), ADMIN_PASSWORD):
            FAILS.pop(ip, None)
            session.clear(); session["admin"] = True; session["csrf"] = secrets.token_hex(16)
            return redirect("/")
        else:
            FAILS[ip] = (n + 1, t0); err = "Password errata."
    return render_template_string("{% extends 'login.html' %}", csrf=session["csrf"], err=err)

@app.route("/logout")
def logout():
    session.clear(); return redirect("/login")

@app.route("/")
@login_required
def index():
    rows = db().execute("SELECT * FROM diag ORDER BY id DESC LIMIT 200").fetchall()
    return render_template_string("{% extends 'index.html' %}", rows=rows, csrf=session["csrf"])

@app.route("/new", methods=["POST"])
@login_required
def new():
    if not csrf_ok(): abort(400)
    label = request.form.get("label", "").strip()[:80] or "senza nome"
    token = secrets.token_urlsafe(24)
    db().execute("INSERT INTO diag(label,token_hash,created,expires) VALUES(?,?,?,?)",
                 (label, hs(token), now(), now() + TTL))
    server = PUBLIC_URL or request.host_url.rstrip("/")
    payload = "netcheck://c?" + urlencode({"s": server, "t": token, "fp": PIN})
    weblink = server + "/a/" + token
    message = ("Ciao! Per il controllo di sicurezza del telefono apri questo link dal tuo telefono Android "
               "e segui le istruzioni:\n" + weblink + "\nIl link vale una volta sola e scade tra 72 ore.")
    buf = io.BytesIO(); qrcode.make(payload, box_size=8, border=2).save(buf, "PNG")
    return render_template_string("{% extends 'qr.html' %}", label=label, pinned=bool(PIN), link=payload, weblink=weblink, message=message,
                                  img=base64.b64encode(buf.getvalue()).decode())

@app.route("/d/<int:i>")
@login_required
def detail(i):
    r = db().execute("SELECT * FROM diag WHERE id=?", (i,)).fetchone() or abort(404)
    rep = json.loads(r["report_json"]) if r["report_json"] else None
    return render_template_string("{% extends 'detail.html' %}", r=r, rep=rep, v=build_view(rep) if rep else None, csrf=session["csrf"])

@app.route("/r/<sess>")
def client_report(sess):
    r = db().execute("SELECT * FROM diag WHERE session_hash=?", (hs(sess),)).fetchone()
    if not r or not r["report_json"]:
        abort(404)
    rep = json.loads(r["report_json"])
    return render_template_string("{% extends 'client.html' %}", r=r, rep=rep, v=build_view(rep))

@app.route("/d/<int:i>/delete", methods=["POST"])
@login_required
def delete(i):
    if not csrf_ok(): abort(400)
    db().execute("DELETE FROM diag WHERE id=?", (i,)); return redirect("/")

# ---------- API per l'app ----------
@app.route("/api/ping")
def ping():
    return jsonify(ip=request.remote_addr, t=now())

@app.route("/api/claim", methods=["POST"])
def claim():
    token = (request.get_json(silent=True) or {}).get("token", "")
    if not isinstance(token, str) or not token: abort(401)
    sess = secrets.token_urlsafe(24)
    cur = db().execute(  # atomico: un solo uso
        "UPDATE diag SET claimed_at=?,session_hash=?,claimed_ip=? "
        "WHERE token_hash=? AND claimed_at IS NULL AND expires>?",
        (now(), hs(sess), request.remote_addr, hs(token), now()))
    if cur.rowcount != 1: abort(401)
    return jsonify(session=sess, duration=DURATION)

def clean(v, n=500):
    return str(v)[:n]

@app.route("/api/report", methods=["POST"])
def report():
    j = request.get_json(silent=True) or {}
    sess = j.get("session", "")
    if not isinstance(sess, str) or not sess: abort(403)
    r = db().execute("SELECT * FROM diag WHERE session_hash=?", (hs(sess),)).fetchone()
    if not r or r["report_json"] or now() > r["claimed_at"] + DURATION + GRACE: abort(403)
    rep = j.get("report")
    if not isinstance(rep, dict): abort(400)
    findings = []
    for f in (rep.get("findings") or [])[:200]:
        if isinstance(f, dict):
            lv = f.get("level", 0)
            findings.append({"id": clean(f.get("id"), 120), "title": clean(f.get("title"), 120),
                             "level": lv if lv in (0, 1, 2) else 0, "detail": clean(f.get("detail"), 1200)})
    def toint(v):
        try:
            return int(v)
        except (TypeError, ValueError):
            return 0
    dns = {}
    for name, d in list((rep.get("dns") or {}).items())[:80]:
        if not isinstance(d, dict):
            continue
        doms = [{"host": clean(x.get("host"), 120), "count": toint(x.get("count"))}
                for x in (d.get("domains") or [])[:40] if isinstance(x, dict)]
        dns[clean(name, 120)] = {"queries": toint(d.get("queries")), "domains": doms}
    apps = []
    for a in (rep.get("apps") or [])[:400]:
        if isinstance(a, dict):
            apps.append({"name": clean(a.get("name"), 120), "pkg": clean(a.get("pkg"), 120),
                         "hidden": bool(a.get("hidden")), "store": bool(a.get("store")),
                         "perms": [clean(p, 12) for p in (a.get("perms") or [])[:10]]})
    dev = rep.get("device") if isinstance(rep.get("device"), dict) else {}
    out = {"findings": findings, "dns": dns, "apps": apps,
           "device": {k: clean(v, 60) for k, v in dev.items()},
           "ips": [clean(x, 45) for x in (rep.get("ips") or [])[:20]],
           "latency_median_ms": rep.get("latency_median_ms"),
           "vpn_capture": bool(rep.get("vpn_capture"))}
    lv = max([f["level"] for f in findings] or [0])
    verdict = ["green", "yellow", "red"][lv]
    cur = db().execute("UPDATE diag SET report_json=?,verdict=?,reported_at=? WHERE id=? AND report_json IS NULL",
                       (json.dumps(out), verdict, now(), r["id"]))
    if cur.rowcount != 1: abort(403)
    v = build_view(out)
    return jsonify(ok=True, report_path="/r/" + sess, headline=v["headline"], intro=v["intro"],
                   items=[{"title": x["title"], "explain": x["explain"], "action": x["action"]} for x in v["cards"] if x["level"] > 0],
                   safety=v["safety"] if v["safety_show"] else "")

if __name__ == "__main__":
    app.run(port=8000)
