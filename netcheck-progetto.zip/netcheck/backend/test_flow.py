import os, sqlite3, secrets, hashlib, time
os.environ.update(ADMIN_PASSWORD="pw", INSECURE_COOKIES="1", NETCHECK_DB="/tmp/t.db")
if os.path.exists("/tmp/t.db"): os.remove("/tmp/t.db")
from app import app
c = app.test_client()
assert c.get("/").status_code == 302
c.get("/login")
with c.session_transaction() as s: csrf = s["csrf"]
assert c.post("/login", data={"password": "pw", "csrf": csrf}).status_code == 302
with c.session_transaction() as s: csrf = s["csrf"]
q = c.post("/new", data={"label": "<b>x</b>", "csrf": csrf}).data
assert b"data:image/png" in q and b"Messaggio da mandare al cliente" in q and b"/a/" in q
tok = secrets.token_urlsafe(8)
d = sqlite3.connect("/tmp/t.db")
d.execute("INSERT INTO diag(label,token_hash,created,expires) VALUES('x',?,?,?)", (hashlib.sha256(tok.encode()).hexdigest(), int(time.time()), int(time.time()) + 100)); d.commit()
a = app.test_client()
wl = a.get("/a/" + tok); assert wl.status_code == 200 and b"netcheck://c" in wl.data and b"Apri NetCheck" in wl.data
assert b"scaduto" in a.get("/a/token-finto").data
assert b"Cosa raccoglie" in a.get("/privacy").data or b"cosa raccoglie" in a.get("/privacy").data.lower()
j = a.post("/api/claim", json={"token": tok}); assert j.status_code == 200
assert a.post("/api/claim", json={"token": tok}).status_code == 401
sess = j.get_json()["session"]
assert b"scaduto" in a.get("/a/" + tok).data
rep = {"findings": [
  {"id": "ioc_dns_Spia (com.spy)", "title": "t", "level": 2, "detail": "evil.example"},
  {"id": "stalker", "title": "t", "level": 1, "detail": "X <script>alert(1)</script>"},
  {"id": "hidden_net_Foo (com.foo)", "title": "t", "level": 1, "detail": "d"},
  {"id": "vpn", "title": "t", "level": 0, "detail": ""},
  {"id": "root", "title": "t", "level": 1, "detail": "/system/xbin/su"},
  {"id": "lock", "title": "t", "level": 0, "detail": ""},
  {"id": "traffic", "title": "t", "level": 0, "detail": "5 ricerche"},
  {"id": "nuovo", "title": "Titolo mio", "level": 1, "detail": "spiega"}],
 "dns": {"Spia (com.spy)": {"queries": 3, "domains": [{"host": "evil.example", "count": 3}]}},
 "apps": [{"name": "Foo <i>", "pkg": "com.foo", "hidden": True, "store": False, "perms": ["mic", "cam"]},
          {"name": "Bar", "pkg": "com.bar", "hidden": False, "store": True, "perms": []}],
 "device": {"model": "X", "brand": "Acme", "patch": "2026-08-05", "apps_user": 2, "apps_system": 90},
 "ips": ["1.2.3.4"], "vpn_capture": True}
assert a.post("/api/report", json={"session": "bad", "report": rep}).status_code == 403
r1 = a.post("/api/report", json={"session": sess, "report": rep}); assert r1.status_code == 200
j1 = r1.get_json()
assert j1["headline"] == "Ci sono segnali importanti" and "1522" in j1["safety"] and j1["report_path"] == "/r/" + sess, j1
assert "Spia (com.spy)" in j1["items"][0]["explain"], j1["items"][0]
assert a.post("/api/report", json={"session": sess, "report": rep}).status_code == 403
pc = a.get("/r/" + sess)
assert pc.status_code == 200
for needle in (b"Cosa fare adesso", b"1522", b"Con chi parlano le app", b"evil.example", b"App installate (2)", b"Dettagli tecnici", b"Acme X", b"Segni di root"):
    assert needle in pc.data, needle
assert b"<script>alert" not in pc.data and b"<i>" not in pc.data
assert a.get("/r/non-esiste").status_code == 404
assert c.get("/d/2").status_code == 200 and b"Elimina" in c.get("/d/2").data
assert b"Elimina" not in pc.data
print("OK")
