package com.netcheck

import java.net.URL
import javax.net.ssl.HttpsURLConnection

/**
 * Lista pubblica di app di sorveglianza (stalkerware) compilata dal gruppo Echap:
 * https://github.com/AssoEchap/stalkerware-indicators  (non e' completa).
 * Scaricata a ogni test; se offline si usa una copia ridotta di nomi distintivi.
 */
object Indicators {
    private const val IOC_URL = "https://raw.githubusercontent.com/AssoEchap/stalkerware-indicators/master/ioc.yaml"

    private val BUNDLED = setOf(
        "com.thetruth", "com.mxspy", "com.spyzee", "com.ispyoo", "com.hellospy", "com.maxxspy", "com.topspy",
        "net.reptilicus.clientapp", "com.ownspy.android", "com.cocospy", "com.spyic", "com.mspy.lite",
        "med.mspy.mspy", "com.eyezy.android", "com.vvt.android.syncmanager", "pl.lidwin.letmespy",
        "com.xnspy.dashboard", "com.panspy.android", "com.spyhumanrev", "com.meuspy", "com.spy2mobile",
        "com.sap4mobile", "com.thewispy", "com.shadyspy.monitor", "com.chaoqi.spyapp", "com.sl360",
        "com.spytoapp.system", "com.metasploit.stage", "com.androidlost", "com.surebrec", "com.lsdroid.cerberus",
        "com.trackview", "com.droidwatcher", "net.majorkernelpanic.spydroid", "com.spynote.software.stubspynote",
        "com.xhunter.client", "com.realtime.spyapp", "com.mobiletracker", "com.mobiletrackerfree.www",
        "wosc.cwf", "org.traccar.client", "com.imonitor.ainfo", "com.panspy.android", "com.wtspy.apps")

    private val PKG = Regex("^[A-Za-z0-9_.-]{5,}$")

    /** Restituisce (nomi pacchetto, true se la lista e' stata scaricata online). */
    fun load(): Pair<Set<String>, Boolean> = try {
        val c = URL(IOC_URL).openConnection() as HttpsURLConnection
        c.connectTimeout = 8_000; c.readTimeout = 15_000
        val text = try { c.inputStream.use { it.readBytes() }.toString(Charsets.UTF_8) } finally { c.disconnect() }
        val set = parse(text)
        if (set.size < 50) throw IllegalStateException("lista troppo piccola")
        (set + BUNDLED) to true
    } catch (e: Exception) { BUNDLED to false }

    fun parse(text: String): Set<String> {
        val out = HashSet<String>(); var inPk = false
        for (line in text.lineSequence()) {
            val t = line.trim()
            if (t == "packages:") { inPk = true; continue }
            if (!inPk) continue
            if (t.startsWith("- ")) {
                val v = t.substring(2).substringBefore(" #").trim()
                if (PKG.matches(v) && v.contains('.')) out += v
            } else if (t.isNotEmpty() && !t.startsWith("#")) inPk = false
        }
        return out
    }
}
