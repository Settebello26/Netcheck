package com.netcheck

import android.app.*
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import android.os.SystemClock
import org.json.JSONArray
import org.json.JSONObject
import kotlin.concurrent.thread

/** Esegue la diagnosi in primo piano: continua anche se cambi app o spegni lo schermo. */
class ScanService : Service() {
    private val CH = "netcheck"
    private var wake: PowerManager.WakeLock? = null

    override fun onBind(i: Intent?): IBinder? = null

    private fun notif(text: String, tap: PendingIntent? = null): Notification {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CH, "Diagnosi", NotificationManager.IMPORTANCE_LOW))
        return Notification.Builder(this, CH).setSmallIcon(R.drawable.ic_stat)
            .setContentTitle("NetCheck").setContentText(text).setOnlyAlertOnce(true)
            .setContentIntent(tap ?: PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE))
            .build()
    }

    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
        if (i == null || RunState.running) return START_NOT_STICKY
        val server = i.getStringExtra("s").orEmpty(); val token = i.getStringExtra("t").orEmpty(); val pin = i.getStringExtra("fp").orEmpty()
        val n = notif("Diagnosi in corso…")
        if (Build.VERSION.SDK_INT >= 29) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC) else startForeground(1, n)
        wake = getSystemService(PowerManager::class.java).newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "netcheck:run").apply { acquire(25 * 60 * 1000L) }
        RunState.reset(); RunState.running = true
        thread {
            try { work(server, token, pin) } catch (e: Exception) { RunState.say("Errore: ${e.message}") }
            finally {
                RunState.running = false; RunState.prog(""); wake?.release()
                stopForeground(STOP_FOREGROUND_REMOVE); stopSelf()
            }
        }
        return START_NOT_STICKY
    }

    private fun work(server: String, token: String, pin: String) {
        val say = RunState::say
        var traffic: Traffic? = null
        var pcapOn = false
        try {
            say("Verifico che la connessione al server non sia intercettata…")
            try { Api.call(server, "/api/ping", pin) } catch (e: Api.PinException) {
                say("🔴 Il certificato del server non corrisponde: la rete sta intercettando l'HTTPS.")
                RunState.alert = "Il certificato visto da questo telefono e' diverso da quello del server. Nessun dato inviato, QR non consumato. Riprova da un'altra rete."
                return
            }
            val cr = Api.call(server, "/api/claim", pin, JSONObject().put("token", token).toString())
            if (cr.code != 200) { say("QR scaduto, gia' usato o non valido."); return }
            val j = JSONObject(cr.body); val session = j.getString("session"); val duration = j.optInt("duration", 600)

            say("Controlli locali…")
            say("Scarico la lista delle app di sorveglianza note…")
            val (stalker, online) = Indicators.load()
            val findings = Checks.run(this, stalker, online).toMutableList()   // prima di PCAPdroid, che usa una VPN
            val dns = Checks.dnsServers(this)

            if (Pcap.installed(packageManager)) {
                say("Avvio PCAPdroid: autorizza la richiesta quando compare.")
                traffic = Traffic(this, dns).also { it.start() }
                pcapOn = true
                RunState.wantPcapStart = true; RunState.onChange?.invoke()
            } else say("PCAPdroid non installato: salto l'analisi del traffico.")

            val lat = mutableListOf<Long>(); val ips = linkedSetOf<String>(); var fails = 0; var pinBad = false
            val end = SystemClock.elapsedRealtime() + duration * 1000L
            val nm = getSystemService(NotificationManager::class.java)
            while (SystemClock.elapsedRealtime() < end) {
                try {
                    val t0 = SystemClock.elapsedRealtime()
                    val r = Api.call(server, "/api/ping", pin)
                    lat += SystemClock.elapsedRealtime() - t0
                    ips += JSONObject(r.body).optString("ip")
                } catch (e: Api.PinException) { pinBad = true } catch (e: Exception) { fails++ }
                val left = (end - SystemClock.elapsedRealtime()) / 1000
                RunState.prog("In corso… ${left}s"); nm.notify(1, notif("In corso… ${left}s"))
                Thread.sleep(30_000)
            }
            RunState.prog("Concludo…")
            traffic?.stop()

            if (pinBad) findings += Finding("pin", "Certificato del server cambiato durante il test", 2, "Possibile intercettazione HTTPS sulla rete")
            findings += if (ips.size > 2) Finding("ip", "IP pubblico instabile", 1, ips.joinToString())
                        else Finding("ip", "IP pubblico", 0, ips.joinToString())
            val med = lat.sorted().getOrNull(lat.size / 2) ?: -1
            if (med > 800) findings += Finding("lat", "Latenza alta", 1, "$med ms (mediana)")
            if (fails > 3) findings += Finding("fail", "Connessione instabile", 1, "$fails richieste fallite")
            var tj = JSONObject()
            if (traffic != null) { val (tt, f) = traffic.summary(); tj = tt; findings += f }

            val report = JSONObject()
                .put("device", JSONObject().put("model", Build.MODEL).put("android", Build.VERSION.RELEASE))
                .put("findings", JSONArray(findings.map { it.json() })).put("traffic", tj)
                .put("ips", JSONArray(ips.toList())).put("latency_median_ms", med).put("pcapdroid", pcapOn)
            val body = JSONObject().put("session", session).put("report", report).toString()
            val up = try { Api.call(server, "/api/report", pin, body) }
                     catch (e: Api.PinException) { Api.call(server, "/api/report", null, body) }
            val lv = findings.maxOf { f -> f.level }
            say("\n" + listOf("🟢 Nessuna deviazione rilevata", "🟡 Alcuni punti da guardare", "🔴 Deviazioni importanti")[lv])
            var shown = false
            if (up.code == 200) try {
                val r = JSONObject(up.body)
                r.optString("intro").takeIf { s -> s.isNotEmpty() }?.let { s -> say(s) }
                val items = r.optJSONArray("items")
                if (items != null) for (i in 0 until items.length()) {
                    val x = items.getJSONObject(i)
                    say("\n• " + x.optString("title")); say(x.optString("explain"))
                    x.optString("action").takeIf { s -> s.isNotEmpty() }?.let { s -> say("Cosa fare: $s") }
                    shown = true
                }
                r.optString("safety").takeIf { s -> s.isNotEmpty() }?.let { s -> say("\n⚠ $s") }
            } catch (e: Exception) { }
            if (!shown) findings.sortedByDescending { f -> f.level }.filter { f -> f.level > 0 }.forEach { f -> say("• ${f.title}: ${f.detail}") }
            say(if (up.code == 200) "\nReport inviato. Non e' un antivirus: sono indizi, non una prova. Il dettaglio completo e' nel report sul sito." else "\nInvio fallito (${up.code}).")
            if (pcapOn) say("Ora ferma PCAPdroid (tocca la notifica o aprilo e premi stop).")
            val stopTap = if (pcapOn) PendingIntent.getActivity(this, 1, Pcap.intent("stop"), PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT) else null
            nm.notify(2, notif(if (pcapOn) "Test finito. Tocca per fermare PCAPdroid." else "Test finito.", stopTap))
        } finally { traffic?.stop() }
    }
}
