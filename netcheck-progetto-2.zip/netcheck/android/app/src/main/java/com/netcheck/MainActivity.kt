package com.netcheck

import android.Manifest
import android.content.ClipboardManager
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.journeyapps.barcodescanner.ScanContract
import com.journeyapps.barcodescanner.ScanOptions

class MainActivity : AppCompatActivity() {
    private lateinit var log: TextView
    private lateinit var progress: TextView
    private lateinit var btn: Button
    private lateinit var paste: Button

    private val scan = registerForActivityResult(ScanContract()) { r -> r.contents?.let(::onQr) }
    private val pcapResult = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        RunState.say(if (r.resultCode == RESULT_OK) "PCAPdroid avviato."
            else "PCAPdroid non avviato (codice ${r.resultCode}): controlla di aver autorizzato la richiesta.")
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(40, 40, 40, 40) }
        root.addView(TextView(this).apply { text = "NetCheck"; textSize = 26f })
        root.addView(TextView(this).apply {
            text = "Diagnosi di rete di 10 minuti, solo con il tuo consenso. Puoi usare altre app durante il test." })
        btn = Button(this).apply { text = "Scansiona QR"; setOnClickListener { scanQr() } }
        paste = Button(this).apply { text = "Ho un link (stesso telefono)"; setOnClickListener { pasteLink() } }
        progress = TextView(this)
        log = TextView(this).apply { textSize = 14f }
        root.addView(btn); root.addView(paste); root.addView(progress)
        root.addView(ScrollView(this).apply { addView(log) }, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED)
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        handleIntent(intent)
    }

    override fun onNewIntent(i: Intent) { super.onNewIntent(i); handleIntent(i) }

    private fun handleIntent(i: Intent?) {
        i?.data?.takeIf { it.scheme == "netcheck" }?.let { onQr(it.toString()); i.data = null }
    }

    override fun onResume() {
        super.onResume()
        RunState.onChange = { runOnUiThread { refresh() } }
        refresh()
    }

    override fun onPause() { RunState.onChange = null; super.onPause() }

    private fun refresh() {
        log.text = synchronized(RunState.log) { RunState.log.toString() }
        progress.text = RunState.progress
        btn.isEnabled = !RunState.running; paste.isEnabled = !RunState.running
        RunState.alert?.let { RunState.alert = null
            AlertDialog.Builder(this).setTitle("Rete sospetta").setMessage(it).setPositiveButton("OK", null).show() }
        if (RunState.wantPcapStart) { RunState.wantPcapStart = false; pcapResult.launch(Pcap.intent("start")) }
    }

    private fun scanQr() = scan.launch(ScanOptions().setDesiredBarcodeFormats(ScanOptions.QR_CODE)
        .setPrompt("Inquadra il QR di NetCheck").setBeepEnabled(false).setOrientationLocked(false))

    private fun pasteLink() {
        val et = EditText(this)
        val clip = (getSystemService(CLIPBOARD_SERVICE) as ClipboardManager).primaryClip?.getItemAt(0)?.text?.toString()
        if (clip?.startsWith("netcheck://") == true) et.setText(clip)
        AlertDialog.Builder(this).setTitle("Incolla il link").setView(et)
            .setPositiveButton("OK") { _, _ -> onQr(et.text.toString().trim()) }
            .setNegativeButton("Annulla", null).show()
    }

    private fun onQr(c: String) {
        val u = Uri.parse(c)
        val server = u.getQueryParameter("s").orEmpty()
        val token = u.getQueryParameter("t").orEmpty()
        val pin = u.getQueryParameter("fp").orEmpty().lowercase()
        if (u.scheme != "netcheck" || !server.startsWith("https://") || token.isEmpty()) { Toast.makeText(this, "QR non valido", Toast.LENGTH_LONG).show(); return }
        AlertDialog.Builder(this).setTitle("Consenso")
            .setMessage("Per circa 10 minuti NetCheck:\n\n" +
                "• controlla certificati, proxy, VPN, DNS, amministratori, accessibilita', notifiche, ADB e app sospette;\n" +
                "• con PCAPdroid osserva i server contattati dalle app (IP, porta, nome del sito).\n\n" +
                "Non legge messaggi, foto o contenuti dei pacchetti. Il report va al server ${Uri.parse(server).host}.\n\n" +
                "Acconsenti?")
            .setPositiveButton("Acconsento") { _, _ ->
                startForegroundService(Intent(this, ScanService::class.java).putExtra("s", server).putExtra("t", token).putExtra("fp", pin))
            }
            .setNegativeButton("Annulla", null).show()
    }
}
