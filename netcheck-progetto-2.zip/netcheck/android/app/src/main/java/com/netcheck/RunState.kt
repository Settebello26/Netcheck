package com.netcheck

/** Stato condiviso tra servizio (che lavora in background) e schermata. */
object RunState {
    val log = StringBuilder()
    @Volatile var running = false
    @Volatile var progress = ""
    @Volatile var alert: String? = null
    @Volatile var wantPcapStart = false
    @Volatile var onChange: (() -> Unit)? = null

    fun say(s: String) { synchronized(log) { log.append(s).append('\n') }; onChange?.invoke() }
    fun prog(s: String) { progress = s; onChange?.invoke() }
    fun reset() { synchronized(log) { log.setLength(0) }; progress = ""; alert = null; wantPcapStart = false }
}
