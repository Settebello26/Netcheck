plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }
android {
    namespace = "com.netcheck"
    compileSdk = 34
    defaultConfig { applicationId = "com.netcheck"; minSdk = 26; targetSdk = 34; versionCode = 1; versionName = "1.0" }
    compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
    kotlinOptions { jvmTarget = "17" }
}
dependencies {
    implementation("androidx.appcompat:appcompat:1.6.1")
    // ZXing: funziona anche senza Google Play Services (GrapheneOS, CalyxOS)
    implementation("com.journeyapps:zxing-android-embedded:4.3.0")
}
