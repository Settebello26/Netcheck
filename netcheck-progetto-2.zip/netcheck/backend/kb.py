"""Testi in italiano semplice per il report. Il livello e' 0 (ok), 1 (attenzione), 2 (importante).
Ogni voce: (titolo, cosa significa, cosa fare). {app} viene sostituito col nome dell'app."""

KB = {
"ca": {
 0: ("Nessun certificato di sicurezza aggiunto",
     "Il telefono si fida solo dei certificati di sicurezza installati di fabbrica. È la situazione normale.", ""),
 2: ("Certificati di sicurezza aggiunti a mano",
     "Sul telefono è stato installato un certificato che permette di leggere anche le connessioni protette (quelle con il lucchetto). È una tecnica usata per spiare il traffico. È legittima solo in aziende o scuole che gestiscono i telefoni.",
     "Vai in Impostazioni → Sicurezza e privacy → Altre impostazioni di sicurezza → Credenziali utente (il nome cambia da telefono a telefono). Se non sai perché ci sono, rimuovili. Se il telefono è aziendale, chiedi all'ufficio informatico.")},
"proxy": {
 0: ("Nessun intermediario nella connessione",
     "Il traffico internet va direttamente ai siti, senza passare da altri computer.", ""),
 2: ("La connessione passa da un intermediario (proxy)",
     "Il traffico del telefono viene mandato a un altro computer prima di arrivare ai siti. Chi lo gestisce può vedere quali siti visiti. Ha senso solo in reti aziendali o scolastiche.",
     "Impostazioni → Connessioni → Wi-Fi → tocca la rete in uso → Proxy, e mettilo su «Nessuno», a meno che tu non sappia perché c'è.")},
"vpn": {
 0: ("Nessuna VPN attiva",
     "Una VPN fa passare il traffico da un servizio esterno. Qui non ce n'è nessuna.", ""),
 1: ("È attiva una VPN",
     "Il traffico del telefono passa da un servizio esterno, che può vedere a quali siti ti colleghi. Va bene se l'hai attivata tu con un servizio di cui ti fidi; è un problema se non l'hai fatto tu.",
     "Impostazioni → Connessioni → Altre impostazioni di connessione → VPN. Se non la riconosci, disattivala.")},
"dns": {
 0: ("Server DNS normali",
     "Il DNS è la «rubrica» che traduce i nomi dei siti in indirizzi. Il telefono usa quella dell'operatore o della rete, ed è la situazione normale.", ""),
 1: ("«Rubrica dei siti» (DNS) insolita",
     "Il telefono usa una rubrica dei siti che non è quella dell'operatore né una delle più note. Chi la gestisce può vedere quali siti cerchi, o mandarti su siti falsi.",
     "Se sei su un Wi-Fi che non conosci, prova con i dati mobili. Per proteggerti attiva «DNS privato» in Impostazioni → Connessioni → Altre impostazioni di connessione.")},
"admin": {
 0: ("Nessun amministratore sospetto",
     "Alcune app possono avere poteri speciali sul telefono (bloccarlo, cancellarlo, impedire di disinstallarle). Qui ci sono solo componenti del produttore, come Samsung, che sono normali.", ""),
 1: ("App con poteri di amministratore",
     "Queste app possono bloccare o cancellare il telefono e impedire di essere rimosse. Le app spia spesso chiedono questi poteri per non farsi disinstallare.",
     "Impostazioni → Sicurezza e privacy → Altre impostazioni di sicurezza → App di amministrazione dispositivo. Disattiva quelle che non riconosci, poi disinstallale.")},
"a11y": {
 0: ("Nessun servizio di accessibilità sospetto",
     "L'accessibilità aiuta chi ha difficoltà a usare il telefono, ma un'app con questo permesso può leggere tutto ciò che appare sullo schermo. Qui non ce ne sono di preoccupanti.", ""),
 1: ("App che possono leggere lo schermo",
     "Queste app hanno il permesso di accessibilità: possono leggere ciò che scrivi e ciò che compare sullo schermo, anche password e messaggi. È un permesso molto usato dalle app spia. Va bene per gestori di password o strumenti per la disabilità che hai installato tu.",
     "Impostazioni → Accessibilità → App installate. Disattiva e disinstalla quelle che non riconosci o non ti servono.")},
"notif": {
 0: ("Nessuna app sospetta legge le notifiche",
     "Alcune app possono leggere le notifiche (messaggi, codici di verifica). Qui sono solo componenti di sistema, normali.", ""),
 1: ("App che leggono le tue notifiche",
     "Queste app possono vedere i messaggi e i codici di sicurezza che arrivano come notifica. È legittimo per smartwatch e app di sistema, sospetto per app sconosciute.",
     "Impostazioni → Notifiche → Accesso alle notifiche. Togli il permesso a quelle che non riconosci.")},
"adb": {
 0: ("Debug USB spento",
     "Il «debug» è una modalità per sviluppatori che permette di controllare il telefono da un computer. È spenta, come deve essere.", ""),
 1: ("Debug USB acceso",
     "Un computer collegato al telefono potrebbe controllarlo. Serve solo agli sviluppatori.",
     "Impostazioni → Opzioni sviluppatore → Debug USB: spegnilo."),
 2: ("Debug wireless acceso",
     "Chiunque sia sulla tua stessa rete Wi-Fi potrebbe provare a controllare il telefono. È raro che serva.",
     "Impostazioni → Opzioni sviluppatore → Debug wireless: spegnilo subito.")},
"stalker": {
 0: ("Nessuna app spia tra quelle conosciute",
     "Ho confrontato le app installate con una lista pubblica di app di sorveglianza, compilata da esperti di sicurezza. Nessuna corrisponde. La lista non è completa, quindi non è una garanzia.", ""),
 1: ("App presente nella lista delle app di sorveglianza",
     "Una delle app installate compare in una lista pubblica di app usate per spiare le persone. Alcune sono anche app legittime (antifurto, controllo parentale): se l'hai installata tu, va bene. Se non la conosci, potrebbe averla messa qualcun altro.",
     "Verifica se l'hai installata tu. Se non la riconosci, leggi il consiglio di sicurezza in fondo prima di rimuoverla."),
 2: ("App nascosta che compare nella lista delle app spia",
     "Un'app senza icona nel menu corrisponde a un'app di sorveglianza conosciuta. È un segnale forte che qualcuno possa controllare il telefono a tua insaputa.",
     "Leggi il consiglio di sicurezza in fondo prima di toccare l'app.")},
"apps_hidden": {
 2: ("App nascoste con molti permessi",
     "Queste app non hanno un'icona nel menu e hanno accesso a cose delicate (microfono, fotocamera, posizione, messaggi). È il comportamento tipico delle app spia, che si nascondono per non farsi trovare.",
     "Impostazioni → App: cerca i nomi indicati nei dettagli. Se non li riconosci, disinstallali. Se pensi che qualcuno ti controlli, leggi prima il consiglio di sicurezza in fondo.")},
"apps_side": {
 1: ("App fuori dagli store con molti permessi",
     "Queste app non vengono dal Play Store o dal Galaxy Store, che fanno dei controlli, e hanno accesso a molte cose delicate.",
     "Verifica di averle installate tu e di fidarti. Altrimenti disinstallale.")},
"apps": {
 0: ("Nessuna app nascosta o anomala con molti permessi",
     "Non ho trovato app nascoste o installate in modo anomalo con molti permessi sensibili. Non è una garanzia: è un controllo parziale.", "")},
"overlay": {
 0: ("App che possono comparire sopra le altre",
     "Alcune app possono disegnarsi sopra le altre (bolle di chat, registratori dello schermo). Quelle trovate sono normali.", ""),
 1: ("App nascoste che possono comparire sopra le altre",
     "Un'app senza icona può mostrarsi sopra le altre: può servire a ingannarti con finte schermate (per esempio di accesso a una banca).",
     "Impostazioni → App → Accesso speciale → Mostra sopra altre app. Togli il permesso alle app che non riconosci.")},
"installer": {
 0: ("App che possono installare altre app",
     "Alcune app (browser, gestori di file) possono installare altre app. Nulla di strano.", ""),
 1: ("App nascoste che possono installare altre app",
     "Un'app senza icona può installare altre app senza che tu te ne accorga.",
     "Impostazioni → App → Accesso speciale → Installa app sconosciute. Togli il permesso alle app che non riconosci.")},
"battery": {
 0: ("App sempre attive in background",
     "Alcune app sono esentate dal risparmio batteria per restare sempre attive. Quelle trovate sono comuni.", ""),
 1: ("App nascoste sempre attive in background",
     "Un'app senza icona che non viene mai fermata dal risparmio batteria è tipica delle app spia, che devono restare attive per registrare.",
     "Impostazioni → App: controlla i nomi indicati nei dettagli e disinstalla quelli che non riconosci.")},
"mic": {
 0: ("App che possono usare microfono e fotocamera",
     "Queste app possono usare microfono e fotocamera. Per app come WhatsApp o Instagram è normale. Android mostra un puntino verde in alto quando sono in uso.",
     "Impostazioni → Privacy → Dashboard privacy: vedi chi ha usato microfono e fotocamera nelle ultime ore. Togli il permesso alle app che non ne hanno bisogno.")},
"patch": {
 0: ("Aggiornamenti di sicurezza recenti",
     "Il telefono ha ricevuto di recente gli aggiornamenti di sicurezza, che chiudono le falle usate dai malintenzionati.", ""),
 1: ("Telefono non aggiornato da molto",
     "Il telefono non riceve aggiornamenti di sicurezza da oltre un anno: sono rimaste aperte falle note.",
     "Impostazioni → Aggiornamento software. Se non ce ne sono più, valuta di cambiare telefono per le cose importanti (banca, email).")},
"pin": {
 2: ("Connessione intercettata durante il test",
     "Mentre il test girava, il certificato del server è cambiato: qualcuno sulla rete sta intercettando le connessioni protette. È tipico di Wi-Fi pubblici manomessi o di strumenti di sorveglianza.",
     "Non usare questa rete per cose importanti (banca, email). Prova con i dati mobili e ripeti il test.")},
"ip": {
 0: ("Indirizzo internet stabile",
     "Durante il test il telefono si è presentato su internet sempre con lo stesso indirizzo. Normale.", ""),
 1: ("Indirizzo internet cambiato più volte",
     "Nei 10 minuti l'indirizzo con cui il telefono si presenta su internet è cambiato più volte. È normale se cambiavi rete o se l'operatore lo assegna in modo dinamico; è strano se il telefono era fermo su un Wi-Fi.",
     "Se eri fermo su un Wi-Fi e succede spesso, ripeti il test.")},
"lat": {
 1: ("Connessione lenta",
     "Il server ha risposto lentamente (oltre 0,8 secondi). Di solito è segnale debole, non un problema di sicurezza.",
     "Ripeti il test dove il segnale è migliore.")},
"fail": {
 1: ("Connessione instabile",
     "Diverse richieste sono fallite durante il test: il risultato potrebbe essere incompleto.",
     "Ripeti il test con una connessione più stabile.")},
"traffic": {
 0: ("Nessuna anomalia nei dati inviati dalle app",
     "Per 10 minuti abbiamo guardato verso quali siti le app inviavano dati (mai il contenuto, solo «chi» e «quanto»). Non abbiamo visto invii strani.", ""),
 1: ("Analisi dei dati inviati non riuscita",
     "Non siamo riusciti a vedere quali dati le app inviavano (di solito perché PCAPdroid non è stato autorizzato). Il resto del report è valido, ma questa parte manca.",
     "Installa PCAPdroid, autorizza la richiesta quando compare e rifai il test.")},
"clear_": {
 1: ("Un'app invia dati senza protezione",
     "L'app «{app}» ha inviato dati con connessioni non cifrate (HTTP): chiunque sulla stessa rete può leggerli.",
     "Aggiorna l'app o non usarla su reti pubbliche. Se non la conosci, disinstallala.")},
"port_": {
 1: ("Un'app invia molti dati in modo insolito",
     "L'app «{app}» ha inviato molti dati su canali che di solito non si usano per navigare. Può essere un gioco o una videochiamata, ma anche un'app spia che manda dati altrove.",
     "Controlla se l'app ti serve. Se non la riconosci, disinstallala.")},
"noname_": {
 1: ("Un'app invia dati a indirizzi senza nome",
     "L'app «{app}» ha inviato quantità consistenti di dati a indirizzi internet senza un nome di sito riconoscibile. I servizi normali di solito hanno un nome, quelli nascosti spesso no.",
     "Controlla l'app. Se non la riconosci o non ti serve, disinstallala.")},
"dns_": {
 1: ("Un'app usa una «rubrica dei siti» tutta sua",
     "L'app «{app}» non usa la rubrica dei siti (DNS) del telefono ma una propria. Alcune app lo fanno per sicurezza, altre per nascondere dove si collegano.",
     "Se non è un'app di cui ti fidi, disinstallala.")},
"err_": {
 0: ("Un controllo non è stato possibile",
     "Questo controllo non ha potuto essere eseguito su questo telefono. Il resto del report è valido.", "")},
}

SAFETY = ("Se pensi che qualcuno (un partner, un ex, un familiare) ti stia controllando, prima di rimuovere app o di fare il ripristino "
          "pensa alla tua sicurezza: chi ha installato l'app potrebbe accorgersi che l'hai tolta. Se puoi, usa un altro telefono o un computer "
          "di cui ti fidi per chiedere aiuto e salva le schermate come prova. In Italia il 1522 è il numero gratuito, attivo 24 ore su 24, "
          "contro violenza e stalking; in caso di pericolo immediato chiama il 112. Per approfondire: stopstalkerware.org.")

GLOSSARIO = [
 ("VPN", "Un servizio che fa passare il traffico internet da un altro computer. Protegge o spia, a seconda di chi lo gestisce."),
 ("DNS", "La «rubrica» che traduce i nomi dei siti (come google.it) negli indirizzi numerici dei computer."),
 ("Proxy", "Un computer intermedio da cui passa il traffico prima di arrivare ai siti."),
 ("Certificato", "Un «documento d'identità» dei siti. Se ne aggiungi uno falso, qualcuno può leggere anche le connessioni protette."),
 ("Accessibilità", "Funzioni per chi ha difficoltà a usare il telefono. Un'app con questo permesso può leggere lo schermo."),
 ("ADB / debug", "Una modalità per sviluppatori che permette di controllare il telefono da un computer."),
 ("Stalkerware", "App spia installate di nascosto sul telefono di una persona per controllarla."),
 ("HTTP", "Navigazione senza cifratura: chiunque sulla rete può leggere i dati. Quella protetta si chiama HTTPS (il lucchetto).")]


def kb_key(i):
    for p in ("clear_", "port_", "noname_", "dns_", "err_"):
        if i.startswith(p):
            return p
    return i


def describe(f):
    i, lv = f["id"], f["level"]
    key = kb_key(i)
    entry = KB.get(key)
    if entry:
        ks = [k for k in entry if k <= lv] or list(entry)
        tpl = entry[max(ks)]
        app = i.split("_", 1)[1] if key.endswith("_") and "_" in i else ""
        title, explain, action = [s.replace("{app}", app) for s in tpl]
    else:
        title, explain, action = f["title"], f["detail"], ""
    return {"id": i, "level": lv, "title": title, "explain": explain, "action": action, "detail": f["detail"]}


def view(rep):
    items = sorted((describe(f) for f in rep.get("findings", [])), key=lambda x: -x["level"])
    n = len(items)
    k = sum(1 for x in items if x["level"] > 0)
    c = sum(1 for x in items if x["level"] == 2)
    lv = max([x["level"] for x in items] or [0])
    if lv == 0:
        headline = "Nessun segnale preoccupante"
        intro = (f"Abbiamo eseguito {n} controlli su impostazioni, app installate, connessione e dati inviati dalle app. "
                 "Non è emerso nulla di anomalo. Attenzione: nessun controllo può garantire al 100% che un telefono sia pulito, "
                 "soprattutto contro spyware professionali.")
    elif lv == 1:
        headline = "Alcuni punti da guardare"
        intro = (f"Abbiamo eseguito {n} controlli. Non abbiamo trovato prove di spionaggio, ma {k} cose meritano un'occhiata. "
                 "Spesso hanno spiegazioni innocenti: leggi le schede qui sotto, una per una.")
    else:
        headline = "Ci sono segnali importanti"
        intro = (f"Abbiamo eseguito {n} controlli e {k} richiedono attenzione, di cui {c} importanti. "
                 "Non significa che ci sia la certezza di essere spiati, ma vanno verificati con calma e al più presto.")
    todo, seen = [], set()
    for x in items:
        if x["level"] > 0 and x["action"] and x["action"] not in seen:
            seen.add(x["action"]); todo.append(x["action"])
    safety_show = lv == 2 or any(x["id"] == "stalker" and x["level"] > 0 for x in items)
    return {"cards": items, "level": lv, "headline": headline, "intro": intro, "todo": todo,
            "safety": SAFETY, "safety_show": safety_show, "glossario": GLOSSARIO}


def human(n):
    n = float(n)
    for u in ("byte", "KB", "MB", "GB"):
        if n < 1024 or u == "GB":
            return (f"{int(n)} {u}" if u == "byte" else f"{n:.1f} {u}".replace(".", ","))
        n /= 1024
