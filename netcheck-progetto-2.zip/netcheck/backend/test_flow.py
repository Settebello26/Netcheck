import os, re
os.environ.update(ADMIN_PASSWORD="pw", INSECURE_COOKIES="1", NETCHECK_DB="/tmp/t.db")
if os.path.exists("/tmp/t.db"): os.remove("/tmp/t.db")
from app import app
from urllib.parse import urlparse, parse_qs
import io
c = app.test_client()
assert c.get("/").status_code == 302
r = c.get("/login"); 
import flask
with c.session_transaction() as s: csrf = s["csrf"]
assert c.post("/login", data={"password":"x","csrf":csrf}).status_code == 200
assert c.post("/login", data={"password":"pw","csrf":csrf}).status_code == 302
with c.session_transaction() as s: csrf = s["csrf"]
assert b"data:image/png" in c.post("/new", data={"label":"<b>x</b>","csrf":csrf}).data
import sqlite3
# recupero un token creandolo direttamente
import secrets, hashlib, time
tok = secrets.token_urlsafe(8)
d = sqlite3.connect("/tmp/t.db")
d.execute("INSERT INTO diag(label,token_hash,created,expires) VALUES('x',?,?,?)",(hashlib.sha256(tok.encode()).hexdigest(),int(time.time()),int(time.time())+100)); d.commit()
a = app.test_client()
j = a.post("/api/claim", json={"token":tok}); assert j.status_code == 200
assert a.post("/api/claim", json={"token":tok}).status_code == 401   # secondo uso rifiutato
sess = j.get_json()["session"]
rep = {"findings":[{"id":"stalker","title":"t","level":2,"detail":"X <b>Y</b>"},{"id":"clear_Foo (com.foo)","title":"t","level":1,"detail":"d"},{"id":"vpn","title":"t","level":0,"detail":""},{"id":"nuovo","title":"Titolo mio","level":1,"detail":"spiega"}],"traffic":{"App":{"bytes_up":5,"dests":[{"host":"h","ip":"1.1.1.1","port":443,"proto":"tcp","bytes":5}]}},"device":{"model":"X"},"ips":["1.2.3.4"]}
assert a.post("/api/report", json={"session":"bad","report":rep}).status_code == 403
r1 = a.post("/api/report", json={"session":sess,"report":rep}); assert r1.status_code == 200; j1 = r1.get_json(); assert "Ci sono segnali importanti" == j1["headline"] and len(j1["items"]) == 3 and "1522" in j1["safety"] and "Foo (com.foo)" in j1["items"][1]["explain"], j1
assert a.post("/api/report", json={"session":sess,"report":rep}).status_code == 403  # secondo report rifiutato
assert a.get("/d/2").status_code == 302                                 # non admin
page = c.get("/d/2"); assert b"Cosa fare adesso" in page.data and b"1522" in page.data and b"Dettagli tecnici" in page.data and b"<b>Y</b>" not in page.data, page.data[:500]
rep["findings"][0]["detail"]="<script>alert(1)</script>"
assert b"<script>alert" not in c.get("/").data
assert b"scarica" in c.get("/scarica").data.lower()
print("OK")
