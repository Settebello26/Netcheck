"""NetCheck backend: QR monouso -> diagnosi di rete con consenso -> report verde/giallo/rosso."""
import os, io, time, json, base64, secrets, hashlib, hmac, sqlite3
from datetime import datetime
from urllib.parse import urlencode
from functools import wraps
from flask import (Flask, request, session, redirect, abort, jsonify, g,
                   render_template_string)
from jinja2 import DictLoader
import qrcode

DB = os.environ.get("NETCHECK_DB", "netcheck.db")
ADMIN_PASSWORD = os.environ.get("ADMIN_PASSWORD") or ""
PUBLIC_URL = os.environ.get("PUBLIC_URL", "").rstrip("/")
PIN = os.environ.get("SERVER_PUBKEY_SHA256", "").replace(":", "").lower()
TTL = 72 * 3600          # validita' del QR
DURATION = 600           # durata diagnosi (s)
GRACE = 1800             # margine per l'invio del report

app = Flask(__name__)
if not ADMIN_PASSWORD:
    raise SystemExit("Imposta la variabile ADMIN_PASSWORD")
app.secret_key = os.environ.get("SECRET_KEY") or secrets.token_hex(32)
app.config.update(
    MAX_CONTENT_LENGTH=512 * 1024, SESSION_COOKIE_HTTPONLY=True,
    SESSION_COOKIE_SAMESITE="Strict",
    SESSION_COOKIE_SECURE=os.environ.get("INSECURE_COOKIES") != "1")
if os.environ.get("TRUST_PROXY") == "1":
    from werkzeug.middleware.proxy_fix import ProxyFix
    app.wsgi_app = ProxyFix(app.wsgi_app, x_for=1, x_proto=1, x_host=1)

# ---------- db ----------
def db():
    if "db" not in g:
        g.db = sqlite3.connect(DB)
        g.db.row_factory = sqlite3.Row
        g.db.execute("""CREATE TABLE IF NOT EXISTS diag(
            id INTEGER PRIMARY KEY, label TEXT, token_hash TEXT UNIQUE,
            created INT, expires INT, claimed_at INT, session_hash TEXT,
            claimed_ip TEXT, report_json TEXT, verdict TEXT, reported_at INT)""")
    return g.db

@app.teardown_appcontext
def close_db(_):
    d = g.pop("db", None)
    if d:
        d.commit(); d.close()

def now(): return int(time.time())
def hs(x): return hashlib.sha256(x.encode()).hexdigest()
def fmt(t): return datetime.fromtimestamp(t).strftime("%d/%m/%Y %H:%M") if t else "-"

def status(r):
    if r["report_json"]: return "completata"
    if r["claimed_at"]:
        return "in corso" if now() < r["claimed_at"] + DURATION + GRACE else "interrotta"
    return "in attesa" if now() < r["expires"] else "scaduta"

app.jinja_env.globals.update(fmt=fmt, status=status)

# ---------- sicurezza ----------
FAILS = {}
def login_required(f):
    @wraps(f)
    def w(*a, **k):
        if not session.get("admin"):
            return redirect("/login")
        return f(*a, **k)
    return w

def csrf_ok():
    return hmac.compare_digest(request.form.get("csrf", ""), session.get("csrf", "x"))

@app.after_request
def headers(r):
    r.headers["X-Content-Type-Options"] = "nosniff"
    r.headers["Cache-Control"] = "no-store"
    r.headers["Content-Security-Policy"] = "default-src 'none'; img-src 'self' data:; style-src 'unsafe-inline'; form-action 'self'"
    return r

# ---------- template ----------
app.jinja_loader = DictLoader({
"base.html": """<!doctype html><html lang=it><meta charset=utf-8>
<meta name=viewport content="width=device-width,initial-scale=1"><title>NetCheck</title>
<style>body{font:16px system-ui;max-width:860px;margin:2rem auto;padding:0 1rem;color:#222}
table{border-collapse:collapse;width:100%}td,th{border-bottom:1px solid #ddd;padding:.5rem;text-align:left;vertical-align:top}
.b{padding:.15rem .6rem;border-radius:1rem;color:#fff;font-weight:600;font-size:.85rem}
.green{background:#2e9d4a}.yellow{background:#d9a400}.red{background:#c62828}.none{background:#777}
input,button{font:inherit;padding:.5rem}button{cursor:pointer}small{color:#666}code{word-break:break-all}</style>
<h1><a href="/" style="color:inherit;text-decoration:none">NetCheck</a></h1>{% block c %}{% endblock %}""",
"login.html": """{% extends 'base.html' %}{% block c %}<form method=post>
<input type=password name=password placeholder=Password autofocus>
<input type=hidden name=csrf value="{{csrf}}"><button>Entra</button></form>{% if err %}<p>{{err}}</p>{% endif %}{% endblock %}""",
"index.html": """{% extends 'base.html' %}{% block c %}
<form method=post action=/new><input name=label placeholder="Etichetta (es. telefono di Marco)" required maxlength=80 size=36>
<input type=hidden name=csrf value="{{csrf}}"><button>Genera QR monouso</button></form>
<h3>Diagnosi</h3><table><tr><th>Etichetta<th>Creata<th>Stato<th>Esito</tr>
{% for r in rows %}<tr><td><a href="/d/{{r.id}}">{{r.label}}</a><td>{{fmt(r.created)}}<td>{{status(r)}}
<td>{% if r.verdict %}<span class="b {{r.verdict}}">{{r.verdict|upper}}</span>{% endif %}</tr>{% endfor %}</table>
<p><a href=/logout>Esci</a></p>{% endblock %}""",
"qr.html": """{% extends 'base.html' %}{% block c %}<h3>{{label}}</h3>
<p>Mostra questo QR <b>una sola volta</b>: non e' piu' recuperabile dopo aver lasciato la pagina. Vale una diagnosi, scade tra 72 ore.</p>
<img src="data:image/png;base64,{{img}}" width=320 height=320>
<p>Dallo stesso telefono? Copia questo link e incollalo in NetCheck (pulsante "Ho un link"):</p>
<p><a href="{{link}}">Apri direttamente in NetCheck (solo da questo telefono)</a></p>
<textarea readonly rows=5 style="width:100%">{{link}}</textarea>
{% if not pinned %}<p><small>Attenzione: SERVER_PUBKEY_SHA256 non impostato, il controllo anti-intercettazione sul server e' disattivato.</small></p>{% endif %}
<p><a href=/>Indietro</a></p>{% endblock %}""",
"dl.html": """{% extends 'base.html' %}{% block c %}<h3>Scarica NetCheck (Android)</h3>
<p>NetCheck fa una diagnosi di rete di 10 minuti <b>solo se acconsenti</b>. Non legge messaggi, foto o contenuti.</p>
<ol><li><a href="/static/netcheck.apk">Scarica l'app (APK)</a></li>
<li>Aprila e, se Android lo chiede, consenti l'installazione da questa fonte (su Samsung: disattiva temporaneamente Blocco automatico).</li>
<li>Facoltativo ma consigliato: installa PCAPdroid (Play Store o F-Droid) per l'analisi del traffico.</li>
<li>Quando ricevi il tuo QR o link personale: inquadra il QR con la fotocamera oppure copia il link e usa "Ho un link" in NetCheck.</li></ol>
<p><small>Ogni QR vale una sola diagnosi e scade dopo 72 ore.</small></p>{% endblock %}""",
"detail.html": """{% extends 'base.html' %}{% block c %}<h3>{{r.label}} <span class="b {{r.verdict or 'none'}}">{{(r.verdict or status(r))|upper}}</span></h3>
<p><small>Creata {{fmt(r.created)}} - Stato: {{status(r)}} - Report: {{fmt(r.reported_at)}}</small></p>
{% if rep %}<p><small>{{rep.device.get('model','?')}} - Android {{rep.device.get('android','?')}} - PCAPdroid: {{'si' if rep.get('pcapdroid') else 'no'}}</small></p>
<table><tr><th>Livello<th>Controllo<th>Dettaglio</tr>
{% for f in rep.findings|sort(attribute='level',reverse=True) %}<tr>
<td><span class="b {{['none','yellow','red'][[f.level,2]|min]}}">{{['info','attenzione','critico'][[f.level,2]|min]}}</span>
<td>{{f.title}}<td>{{f.detail}}</tr>{% endfor %}</table>
<h4>Rete</h4><p>IP osservati: {{rep.ips|join(', ')}}<br>Latenza mediana: {{rep.get('latency_median_ms','?')}} ms</p>
{% if rep.traffic %}<h4>Traffico per app</h4>{% for app, d in rep.traffic.items() %}
<details><summary><b>{{app}}</b> - {{d.bytes_up}} byte inviati</summary><table>
{% for x in d.dests %}<tr><td>{{x.host or '(senza nome)'}}<td>{{x.ip}}:{{x.port}}/{{x.proto}}<td>{{x.bytes}} B</tr>{% endfor %}</table></details>{% endfor %}{% endif %}
{% endif %}
<form method=post action="/d/{{r.id}}/delete" onsubmit="return confirm('Eliminare?')"><input type=hidden name=csrf value="{{csrf}}"><button>Elimina</button></form>
<p><small>Non e' un antivirus: segnala indicatori, non prova che un telefono sia pulito.</small></p>{% endblock %}"""})

# ---------- admin ----------
@app.route("/scarica")
def scarica():
    return render_template_string("{% extends 'dl.html' %}")

@app.route("/login", methods=["GET", "POST"])
def login():
    session.setdefault("csrf", secrets.token_hex(16))
    err = None
    if request.method == "POST":
        ip = request.remote_addr
        n, t0 = FAILS.get(ip, (0, now()))
        if now() - t0 > 900: n, t0 = 0, now()
        if n >= 5:
            err = "Troppi tentativi, riprova piu' tardi."
        elif csrf_ok() and hmac.compare_digest(request.form.get("password", ""), ADMIN_PASSWORD):
            FAILS.pop(ip, None)
            session.clear(); session["admin"] = True; session["csrf"] = secrets.token_hex(16)
            return redirect("/")
        else:
            FAILS[ip] = (n + 1, t0); err = "Password errata."
    return render_template_string("{% extends 'login.html' %}", csrf=session["csrf"], err=err)

@app.route("/logout")
def logout():
    session.clear(); return redirect("/login")

@app.route("/")
@login_required
def index():
    rows = db().execute("SELECT * FROM diag ORDER BY id DESC LIMIT 200").fetchall()
    return render_template_string("{% extends 'index.html' %}", rows=rows, csrf=session["csrf"])

@app.route("/new", methods=["POST"])
@login_required
def new():
    if not csrf_ok(): abort(400)
    label = request.form.get("label", "").strip()[:80] or "senza nome"
    token = secrets.token_urlsafe(24)
    db().execute("INSERT INTO diag(label,token_hash,created,expires) VALUES(?,?,?,?)",
                 (label, hs(token), now(), now() + TTL))
    server = PUBLIC_URL or request.host_url.rstrip("/")
    payload = "netcheck://c?" + urlencode({"s": server, "t": token, "fp": PIN})
    buf = io.BytesIO(); qrcode.make(payload, box_size=8, border=2).save(buf, "PNG")
    return render_template_string("{% extends 'qr.html' %}", label=label, pinned=bool(PIN), link=payload,
                                  img=base64.b64encode(buf.getvalue()).decode())

@app.route("/d/<int:i>")
@login_required
def detail(i):
    r = db().execute("SELECT * FROM diag WHERE id=?", (i,)).fetchone() or abort(404)
    rep = json.loads(r["report_json"]) if r["report_json"] else None
    return render_template_string("{% extends 'detail.html' %}", r=r, rep=rep, csrf=session["csrf"])

@app.route("/d/<int:i>/delete", methods=["POST"])
@login_required
def delete(i):
    if not csrf_ok(): abort(400)
    db().execute("DELETE FROM diag WHERE id=?", (i,)); return redirect("/")

# ---------- API per l'app ----------
@app.route("/api/ping")
def ping():
    return jsonify(ip=request.remote_addr, t=now())

@app.route("/api/claim", methods=["POST"])
def claim():
    token = (request.get_json(silent=True) or {}).get("token", "")
    if not isinstance(token, str) or not token: abort(401)
    sess = secrets.token_urlsafe(24)
    cur = db().execute(  # atomico: un solo uso
        "UPDATE diag SET claimed_at=?,session_hash=?,claimed_ip=? "
        "WHERE token_hash=? AND claimed_at IS NULL AND expires>?",
        (now(), hs(sess), request.remote_addr, hs(token), now()))
    if cur.rowcount != 1: abort(401)
    return jsonify(session=sess, duration=DURATION)

def clean(v, n=500):
    return str(v)[:n]

@app.route("/api/report", methods=["POST"])
def report():
    j = request.get_json(silent=True) or {}
    sess = j.get("session", "")
    if not isinstance(sess, str) or not sess: abort(403)
    r = db().execute("SELECT * FROM diag WHERE session_hash=?", (hs(sess),)).fetchone()
    if not r or r["report_json"] or now() > r["claimed_at"] + DURATION + GRACE: abort(403)
    rep = j.get("report")
    if not isinstance(rep, dict): abort(400)
    findings = []
    for f in (rep.get("findings") or [])[:200]:
        if isinstance(f, dict):
            lv = f.get("level", 0)
            findings.append({"id": clean(f.get("id"), 40), "title": clean(f.get("title"), 120),
                             "level": lv if lv in (0, 1, 2) else 0, "detail": clean(f.get("detail"))})
    traffic = {}
    for name, d in list((rep.get("traffic") or {}).items())[:60]:
        dests = [{"host": clean(x.get("host") or "", 120), "ip": clean(x.get("ip"), 45),
                  "port": int(x.get("port", 0)), "proto": clean(x.get("proto"), 5),
                  "bytes": int(x.get("bytes", 0))} for x in (d.get("dests") or [])[:30]]
        traffic[clean(name, 80)] = {"bytes_up": int(d.get("bytes_up", 0)), "dests": dests}
    dev = rep.get("device") if isinstance(rep.get("device"), dict) else {}
    out = {"findings": findings, "traffic": traffic,
           "device": {k: clean(v, 60) for k, v in dev.items()},
           "ips": [clean(x, 45) for x in (rep.get("ips") or [])[:20]],
           "latency_median_ms": rep.get("latency_median_ms"),
           "pcapdroid": bool(rep.get("pcapdroid"))}
    lv = max([f["level"] for f in findings] or [0])
    verdict = ["green", "yellow", "red"][lv]
    cur = db().execute("UPDATE diag SET report_json=?,verdict=?,reported_at=? WHERE id=? AND report_json IS NULL",
                       (json.dumps(out), verdict, now(), r["id"]))
    if cur.rowcount != 1: abort(403)
    return jsonify(ok=True)

if __name__ == "__main__":
    app.run(port=8000)
