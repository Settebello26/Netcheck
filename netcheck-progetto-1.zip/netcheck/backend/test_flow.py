import os, re
os.environ.update(ADMIN_PASSWORD="pw", INSECURE_COOKIES="1", NETCHECK_DB="/tmp/t.db")
if os.path.exists("/tmp/t.db"): os.remove("/tmp/t.db")
from app import app
from urllib.parse import urlparse, parse_qs
import io
c = app.test_client()
assert c.get("/").status_code == 302
r = c.get("/login"); 
import flask
with c.session_transaction() as s: csrf = s["csrf"]
assert c.post("/login", data={"password":"x","csrf":csrf}).status_code == 200
assert c.post("/login", data={"password":"pw","csrf":csrf}).status_code == 302
with c.session_transaction() as s: csrf = s["csrf"]
assert b"data:image/png" in c.post("/new", data={"label":"<b>x</b>","csrf":csrf}).data
import sqlite3
# recupero un token creandolo direttamente
import secrets, hashlib, time
tok = secrets.token_urlsafe(8)
d = sqlite3.connect("/tmp/t.db")
d.execute("INSERT INTO diag(label,token_hash,created,expires) VALUES('x',?,?,?)",(hashlib.sha256(tok.encode()).hexdigest(),int(time.time()),int(time.time())+100)); d.commit()
a = app.test_client()
j = a.post("/api/claim", json={"token":tok}); assert j.status_code == 200
assert a.post("/api/claim", json={"token":tok}).status_code == 401   # secondo uso rifiutato
sess = j.get_json()["session"]
rep = {"findings":[{"id":"a","title":"t","level":2,"detail":"d"}],"traffic":{"App":{"bytes_up":5,"dests":[{"host":"h","ip":"1.1.1.1","port":443,"proto":"tcp","bytes":5}]}},"device":{"model":"X"},"ips":["1.2.3.4"]}
assert a.post("/api/report", json={"session":"bad","report":rep}).status_code == 403
assert a.post("/api/report", json={"session":sess,"report":rep}).status_code == 200
assert a.post("/api/report", json={"session":sess,"report":rep}).status_code == 403  # secondo report rifiutato
assert a.get("/d/2").status_code == 302                                 # non admin
page = c.get("/d/2"); assert b"RED" in page.data, page.data[:300]
rep["findings"][0]["detail"]="<script>alert(1)</script>"
assert b"<script>alert" not in c.get("/").data
assert b"scarica" in c.get("/scarica").data.lower()
print("OK")
