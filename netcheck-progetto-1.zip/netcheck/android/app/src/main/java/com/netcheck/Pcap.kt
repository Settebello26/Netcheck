package com.netcheck

import android.content.Intent
import android.content.pm.PackageManager

/** API di controllo di PCAPdroid: UDP exporter locale + trailer con l'app di ogni pacchetto. */
object Pcap {
    const val PKG = "com.emanuelef.remote_capture"

    fun installed(pm: PackageManager) = try { pm.getPackageInfo(PKG, 0); true } catch (e: Exception) { false }

    fun intent(action: String) = Intent(Intent.ACTION_MAIN).apply {
        setClassName(PKG, "$PKG.activities.CaptureCtrl")
        putExtra("action", action)
        if (action == "start") {
            putExtra("pcap_dump_mode", "udp_exporter")
            putExtra("collector_ip_address", "127.0.0.1")
            putExtra("collector_port", Traffic.PORT)
            putExtra("pcapdroid_trailer", true)
        }
    }
}
