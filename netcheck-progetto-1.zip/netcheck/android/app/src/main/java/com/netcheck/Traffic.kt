package com.netcheck

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress
import kotlin.concurrent.thread

/**
 * Riceve da PCAPdroid (UDP exporter su 127.0.0.1) i pacchetti IP, li attribuisce alle app
 * (trailer PCAPdroid) e ne estrae: server contattati, nome (SNI/DNS), HTTP in chiaro,
 * DNS esterni, upload su porte insolite. Non salva mai il contenuto dei pacchetti.
 */
class Traffic(private val ctx: Context, private val dnsServers: Set<String>) {
    companion object { const val PORT = 5123 }

    private class Flow(val ip: String, val port: Int, val proto: String) { var up = 0L; var name: String? = null; var clear = false }

    private val flows = HashMap<String, MutableMap<String, Flow>>()   // app -> chiave flusso
    private val dnsMap = HashMap<String, String>()
    private val extDns = HashMap<String, MutableSet<String>>()
    private val uidCache = HashMap<Int, String>()
    @Volatile private var running = false
    private var sock: DatagramSocket? = null
    var packets = 0L; private set

    private fun ByteArray.u8(i: Int) = this[i].toInt() and 0xff
    private fun ByteArray.u16(i: Int) = (u8(i) shl 8) or u8(i + 1)
    private fun ByteArray.be32(i: Int) = (u16(i).toLong() shl 16) or u16(i + 2).toLong()

    fun start() {
        running = true
        val s = DatagramSocket(PORT, InetAddress.getByName("127.0.0.1")); sock = s
        thread(isDaemon = true) {
            val buf = ByteArray(65535); val p = DatagramPacket(buf, buf.size)
            while (running) {
                try { p.length = buf.size; s.receive(p); synchronized(this) { handle(buf.copyOf(p.length)) } }
                catch (e: Exception) { if (!running) break }
            }
        }
    }

    fun stop() { running = false; sock?.close() }

    private fun appName(uid: Int, raw: String): String = uidCache.getOrPut(uid) {
        val pm = ctx.packageManager
        val pkg = if (uid >= 0) pm.getPackagesForUid(uid)?.firstOrNull() else null
        if (pkg != null) try { pm.getApplicationLabel(pm.getApplicationInfo(pkg, 0)).toString() + " ($pkg)" } catch (e: Exception) { pkg }
        else raw.ifEmpty { "sconosciuta" }
    }

    private fun handle(d: ByteArray) {
        // Localizza il pacchetto IP: con o senza header record pcap (16 byte).
        var s = if (d.size > 16 && (d.u8(16) shr 4) in intArrayOf(4, 6)) 16 else 0
        if (d.size <= s || (d.u8(s) shr 4) !in intArrayOf(4, 6)) return
        val v6 = (d.u8(s) shr 4) == 6
        val total = if (v6) 40 + d.u16(s + 4) else d.u16(s + 2)
        if (s + total > d.size) return
        packets++
        // Trailer PCAPdroid: magic(4) uid(4) nome(20) fcs(4)
        var uid = -1; var raw = ""
        val t = s + total
        if (d.size - t >= 32 && d.be32(t) == 0x01072021L) {
            uid = d.be32(t + 4).toInt()
            raw = String(d, t + 8, 20).trim { it == '\u0000' || it == ' ' }
        }
        val ipLen = if (v6) 16 else 4
        val hdr = if (v6) 40 else (d.u8(s) and 0xf) * 4
        val proto = if (v6) d.u8(s + 6) else d.u8(s + 9)
        val srcOff = s + if (v6) 8 else 12
        val dstOff = srcOff + ipLen
        val src = InetAddress.getByAddress(d.copyOfRange(srcOff, srcOff + ipLen))
        val dst = InetAddress.getByAddress(d.copyOfRange(dstOff, dstOff + ipLen))
        val l4 = s + hdr
        if (l4 + 8 > t) return
        val sport = d.u16(l4); val dport = d.u16(l4 + 2)
        val pStart = if (proto == 6) l4 + (d.u8(l4 + 12) shr 4) * 4 else l4 + 8
        if (proto != 6 && proto != 17) return
        if (pStart > t) return

        if (proto == 17 && sport == 53) { dnsResponse(d, pStart, t); return }
        if (Checks.isPrivate(src).not() || Checks.isPrivate(dst)) return   // solo traffico in uscita verso Internet

        val app = appName(uid, raw)
        val pLen = t - pStart
        val dstIp = dst.hostAddress ?: return
        val pn = if (proto == 6) "tcp" else "udp"
        val f = flows.getOrPut(app) { HashMap() }.getOrPut("$dstIp|$dport|$pn") { Flow(dstIp, dport, pn) }
        f.up += pLen.coerceAtLeast(0)
        if (proto == 17 && dport == 53) { if (dstIp !in dnsServers) extDns.getOrPut(app) { HashSet() } += dstIp }
        if (proto == 6 && pLen > 5) {
            if (d.u8(pStart) == 0x16 && d.u8(pStart + 5) == 1) sni(d, pStart, t)?.let { f.name = it }
            else if (dport == 80) {
                val head = String(d, pStart, minOf(pLen, 300), Charsets.ISO_8859_1)
                if (Regex("^(GET|POST|PUT|HEAD|DELETE|PATCH) ").containsMatchIn(head)) {
                    f.clear = true
                    Regex("(?i)\\r\\nHost: ([^\\r\\n]+)").find(head)?.let { f.name = it.groupValues[1] }
                }
            }
        }
    }

    private fun sni(d: ByteArray, s: Int, end: Int): String? = try {
        var p = s + 5 + 4 + 2 + 32
        p += 1 + d.u8(p); p += 2 + d.u16(p); p += 1 + d.u8(p)
        val extEnd = p + 2 + d.u16(p); p += 2
        var r: String? = null
        while (p + 4 <= minOf(extEnd, end) && r == null) {
            val type = d.u16(p); val len = d.u16(p + 2)
            if (type == 0) { val n = d.u16(p + 7); r = String(d, p + 9, n, Charsets.US_ASCII) }
            p += 4 + len
        }
        r
    } catch (e: Exception) { null }

    private fun skipName(d: ByteArray, start: Int): Int {
        var p = start
        while (true) { val l = d.u8(p); if (l == 0) return p + 1; if (l and 0xc0 == 0xc0) return p + 2; p += l + 1 }
    }

    private fun readName(d: ByteArray, start: Int, depth: Int = 0): String {
        val sb = StringBuilder(); var p = start
        while (depth < 5) {
            val l = d.u8(p)
            if (l == 0) break
            if (l and 0xc0 == 0xc0) { sb.append(readName(d, ((l and 0x3f) shl 8) or d.u8(p + 1), depth + 1)); break }
            sb.append(String(d, p + 1, l, Charsets.US_ASCII)).append('.'); p += l + 1
        }
        return sb.toString().trimEnd('.')
    }

    private fun dnsResponse(d: ByteArray, s: Int, end: Int) = try {
        val qd = d.u16(s + 4); val an = d.u16(s + 6)
        var p = s + 12
        repeat(qd) { p = skipName(d, p) + 4 }
        val qname = if (qd > 0) readName(d, s + 12) else ""
        repeat(an) {
            val nameEnd = skipName(d, p); val type = d.u16(nameEnd); val rl = d.u16(nameEnd + 8)
            val rd = nameEnd + 10
            if ((type == 1 && rl == 4) || (type == 28 && rl == 16))
                dnsMap[InetAddress.getByAddress(d.copyOfRange(rd, rd + rl)).hostAddress ?: ""] = qname
            p = rd + rl
        }
    } catch (e: Exception) { }

    private val COMMON = setOf(80, 443, 53, 853, 123, 5228, 5229, 5230, 5222, 5223, 993, 995, 587, 465, 143)

    /** Restituisce (traffico per app in JSON, anomalie). */
    fun summary(): Pair<JSONObject, List<Finding>> = synchronized(this) {
        val traffic = JSONObject(); val out = mutableListOf<Finding>()
        for ((app, m) in flows) {
            for (f in m.values) if (f.name == null) f.name = dnsMap[f.ip]
            val list = m.values.sortedByDescending { it.up }
            val dests = JSONArray()
            list.take(30).forEach { dests.put(JSONObject().put("host", it.name ?: "").put("ip", it.ip)
                .put("port", it.port).put("proto", it.proto).put("bytes", it.up)) }
            traffic.put(app, JSONObject().put("bytes_up", list.sumOf { it.up }).put("dests", dests))
            fun d(l: List<Flow>) = l.take(6).joinToString { "${it.name ?: it.ip}:${it.port}" }
            list.filter { it.clear }.let { if (it.isNotEmpty()) out += Finding("clear_$app", "Dati in chiaro (HTTP): $app", 1, d(it)) }
            list.filter { it.port !in COMMON && it.up > 20_000 }.let {
                if (it.isNotEmpty()) out += Finding("port_$app", "Upload su porte insolite: $app", 1, d(it)) }
            list.filter { it.name == null && it.up > 50_000 }.let {
                if (it.isNotEmpty()) out += Finding("noname_$app", "Invio a IP senza nome: $app", 1, d(it)) }
        }
        for ((app, ips) in extDns) out += Finding("dns_$app", "DNS esterno usato da $app", 1, ips.joinToString())
        if (out.isEmpty()) out += Finding("traffic", "Nessuna anomalia nel traffico osservato", 0, "$packets pacchetti analizzati")
        traffic to out
    }
}
