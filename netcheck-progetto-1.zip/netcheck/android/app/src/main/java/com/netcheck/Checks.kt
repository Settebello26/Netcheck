package com.netcheck

import android.app.admin.DevicePolicyManager
import android.content.Context
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.Build
import android.provider.Settings
import org.json.JSONObject
import java.net.InetAddress
import java.security.KeyStore
import java.security.cert.X509Certificate
import java.text.SimpleDateFormat
import java.util.Locale

/** level: 0 info, 1 attenzione, 2 critico */
data class Finding(val id: String, val title: String, val level: Int, val detail: String) {
    fun json(): JSONObject = JSONObject().put("id", id).put("title", title).put("level", level).put("detail", detail)
}

object Checks {
    private val SENSITIVE = setOf(
        "android.permission.RECORD_AUDIO", "android.permission.CAMERA",
        "android.permission.ACCESS_FINE_LOCATION", "android.permission.ACCESS_BACKGROUND_LOCATION",
        "android.permission.READ_SMS", "android.permission.RECEIVE_SMS",
        "android.permission.READ_CONTACTS", "android.permission.READ_CALL_LOG",
        "android.permission.READ_PHONE_STATE")
    private val KNOWN_DNS = setOf("1.1.1.1", "1.0.0.1", "8.8.8.8", "8.8.4.4", "9.9.9.9", "149.112.112.112",
        "208.67.222.222", "208.67.220.220", "94.140.14.14", "94.140.15.15")

    fun isPrivate(a: InetAddress): Boolean {
        val b = a.address
        return a.isSiteLocalAddress || a.isLoopbackAddress || a.isLinkLocalAddress ||
            (b.size == 16 && (b[0].toInt() and 0xfe) == 0xfc)
    }

    fun dnsServers(ctx: Context): Set<String> {
        val cm = ctx.getSystemService(ConnectivityManager::class.java)
        return cm.getLinkProperties(cm.activeNetwork)?.dnsServers?.mapNotNull { it.hostAddress }?.toSet() ?: emptySet()
    }

    fun run(ctx: Context): List<Finding> {
        val out = mutableListOf<Finding>()
        val steps = listOf<Pair<String, (Context, MutableList<Finding>) -> Unit>>(
            "Certificati CA" to ::userCas, "Proxy" to ::proxy, "VPN" to ::vpn, "DNS" to ::dns,
            "Amministratori" to ::admins, "Accessibilita'" to ::accessibility,
            "Lettura notifiche" to ::listeners, "ADB" to ::adb, "App sospette" to ::apps,
            "Patch di sicurezza" to ::patch)
        for ((name, fn) in steps) {
            try { fn(ctx, out) } catch (e: Exception) {
                out += Finding("err_$name", "Controllo non riuscito: $name", 0, e.javaClass.simpleName)
            }
        }
        return out
    }

    private fun label(ctx: Context, pkg: String) = try {
        val pm = ctx.packageManager; "${pm.getApplicationLabel(pm.getApplicationInfo(pkg, 0))} ($pkg)"
    } catch (e: Exception) { pkg }

    private fun isSystem(ctx: Context, pkg: String) = try {
        ctx.packageManager.getApplicationInfo(pkg, 0).flags and ApplicationInfo.FLAG_SYSTEM != 0
    } catch (e: Exception) { false }

    private fun userCas(ctx: Context, o: MutableList<Finding>) {
        val ks = KeyStore.getInstance("AndroidCAStore").apply { load(null) }
        val user = ks.aliases().toList().filter { it.startsWith("user:") }
        if (user.isEmpty()) o += Finding("ca", "Nessun certificato CA aggiunto dall'utente", 0, "Sistema pulito")
        else o += Finding("ca", "Certificati CA installati manualmente", 2,
            "Permettono di intercettare l'HTTPS: " + user.joinToString("; ") {
                (ks.getCertificate(it) as? X509Certificate)?.subjectX500Principal?.name ?: it })
    }

    private fun proxy(ctx: Context, o: MutableList<Finding>) {
        val cm = ctx.getSystemService(ConnectivityManager::class.java)
        val p = cm.defaultProxy ?: cm.getLinkProperties(cm.activeNetwork)?.httpProxy
        val sys = System.getProperty("http.proxyHost")
        if (p == null && sys.isNullOrEmpty()) o += Finding("proxy", "Nessun proxy configurato", 0, "")
        else o += Finding("proxy", "Proxy di rete attivo", 2, p?.toString() ?: sys.orEmpty())
    }

    private fun vpn(ctx: Context, o: MutableList<Finding>) {
        val cm = ctx.getSystemService(ConnectivityManager::class.java)
        val vpn = cm.getNetworkCapabilities(cm.activeNetwork)?.hasTransport(NetworkCapabilities.TRANSPORT_VPN) == true
        o += if (vpn) Finding("vpn", "VPN attiva", 1, "Tutto il traffico passa da un terzo (normale se e' la tua VPN)")
        else Finding("vpn", "Nessuna VPN attiva", 0, "")
    }

    private fun dns(ctx: Context, o: MutableList<Finding>) {
        val cm = ctx.getSystemService(ConnectivityManager::class.java)
        val lp = cm.getLinkProperties(cm.activeNetwork) ?: return
        val odd = lp.dnsServers.filter { !isPrivate(it) && it.hostAddress !in KNOWN_DNS }
        val priv = if (lp.isPrivateDnsActive) "DNS privato attivo (${lp.privateDnsServerName ?: "auto"})" else "DNS privato non attivo"
        val list = lp.dnsServers.joinToString { it.hostAddress ?: "?" }
        o += if (odd.isEmpty()) Finding("dns", "DNS: $list", 0, priv)
        else Finding("dns", "DNS sconosciuti", 1, "${odd.joinToString { it.hostAddress ?: "?" }}. $priv")
    }

    private fun admins(ctx: Context, o: MutableList<Finding>) {
        val dpm = ctx.getSystemService(DevicePolicyManager::class.java)
        val a = dpm.activeAdmins?.map { it.packageName } ?: emptyList()
        o += if (a.isEmpty()) Finding("admin", "Nessun amministratore del dispositivo", 0, "")
        else Finding("admin", "Amministratori del dispositivo attivi", 1, a.joinToString { label(ctx, it) })
    }

    private fun components(raw: String?) = raw.orEmpty().split(":").filter { it.contains("/") }
        .map { it.substringBefore("/") }.distinct()

    private fun accessibility(ctx: Context, o: MutableList<Finding>) {
        val l = components(Settings.Secure.getString(ctx.contentResolver, "enabled_accessibility_services"))
        o += if (l.isEmpty()) Finding("a11y", "Nessun servizio di accessibilita'", 0, "")
        else Finding("a11y", "Servizi di accessibilita' attivi", if (l.any { !isSystem(ctx, it) }) 1 else 0,
            "Possono leggere lo schermo: " + l.joinToString { label(ctx, it) })
    }

    private fun listeners(ctx: Context, o: MutableList<Finding>) {
        val l = components(Settings.Secure.getString(ctx.contentResolver, "enabled_notification_listeners"))
        o += if (l.isEmpty()) Finding("notif", "Nessuna app legge le notifiche", 0, "")
        else Finding("notif", "App con lettura delle notifiche", if (l.any { !isSystem(ctx, it) }) 1 else 0,
            l.joinToString { label(ctx, it) })
    }

    private fun adb(ctx: Context, o: MutableList<Finding>) {
        val cr = ctx.contentResolver
        val usb = Settings.Global.getInt(cr, Settings.Global.ADB_ENABLED, 0) == 1
        val wifi = Settings.Global.getInt(cr, "adb_wifi_enabled", 0) == 1
        o += when {
            wifi -> Finding("adb", "Debug wireless (ADB) attivo", 2, "Accessibile dalla rete locale")
            usb -> Finding("adb", "Debug USB (ADB) attivo", 1, "Normale solo se sei uno sviluppatore")
            else -> Finding("adb", "ADB disattivato", 0, "")
        }
    }

    @Suppress("DEPRECATION")
    private fun apps(ctx: Context, o: MutableList<Finding>) {
        val pm = ctx.packageManager
        val hidden = mutableListOf<String>(); val side = mutableListOf<String>()
        for (p in pm.getInstalledPackages(PackageManager.GET_PERMISSIONS)) {
            val ai = p.applicationInfo ?: continue
            if (ai.flags and ApplicationInfo.FLAG_SYSTEM != 0 || p.packageName == ctx.packageName) continue
            val req = p.requestedPermissions ?: continue
            val fl = p.requestedPermissionsFlags ?: continue
            val score = req.indices.count { req[it] in SENSITIVE && fl[it] and PackageInfo_GRANTED != 0 }
            val installer = if (Build.VERSION.SDK_INT >= 30) pm.getInstallSourceInfo(p.packageName).installingPackageName
                            else pm.getInstallerPackageName(p.packageName)
            val noIcon = pm.getLaunchIntentForPackage(p.packageName) == null
            if (noIcon && score >= 4) hidden += "${label(ctx, p.packageName)} [$score permessi sensibili]"
            else if (installer == null && score >= 5) side += "${label(ctx, p.packageName)} [$score]"
        }
        if (hidden.isNotEmpty()) o += Finding("apps_hidden", "App senza icona con molti permessi sensibili", 2, hidden.joinToString("; "))
        if (side.isNotEmpty()) o += Finding("apps_side", "App installate fuori da uno store con molti permessi", 1, side.joinToString("; "))
        if (hidden.isEmpty() && side.isEmpty()) o += Finding("apps", "Nessuna app sospetta con i criteri usati", 0, "Euristica: non e' un antivirus")
    }
    private const val PackageInfo_GRANTED = android.content.pm.PackageInfo.REQUESTED_PERMISSION_GRANTED

    private fun patch(ctx: Context, o: MutableList<Finding>) {
        val d = SimpleDateFormat("yyyy-MM-dd", Locale.US).parse(Build.VERSION.SECURITY_PATCH) ?: return
        val months = (System.currentTimeMillis() - d.time) / (30L * 24 * 3600 * 1000)
        o += Finding("patch", "Patch di sicurezza: ${Build.VERSION.SECURITY_PATCH}", if (months > 12) 1 else 0,
            if (months > 12) "Vecchia di $months mesi: vulnerabilita' note non corrette" else "Aggiornata")
    }
}
